
package GUI;

import NapakalakiGame.Monster;

public class MonsterView extends javax.swing.JPanel {
Monster monsterModel;

    public MonsterView() {
        initComponents();
    }
    public void setMonster (Monster m) {
        monsterModel = m;
        
        Titulo.setText(monsterModel.getName().toString());
        Nivel.setText(Integer.toString(monsterModel.getCombatLevel()));
        badConsequenceView2.setBadConsequence(monsterModel);
        prizeView2.setPrize(monsterModel);
        repaint();
        revalidate();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Titulo = new javax.swing.JLabel();
        badConsequenceView2 = new GUI.BadConsequenceView();
        prizeView2 = new GUI.PrizeView();
        Nivel = new javax.swing.JLabel();

        Titulo.setText("Titulo");

        badConsequenceView2.setBorder(javax.swing.BorderFactory.createTitledBorder("BadConsequence"));

        javax.swing.GroupLayout badConsequenceView2Layout = new javax.swing.GroupLayout(badConsequenceView2);
        badConsequenceView2.setLayout(badConsequenceView2Layout);
        badConsequenceView2Layout.setHorizontalGroup(
            badConsequenceView2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 192, Short.MAX_VALUE)
        );
        badConsequenceView2Layout.setVerticalGroup(
            badConsequenceView2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        prizeView2.setBorder(javax.swing.BorderFactory.createTitledBorder("Prize"));

        javax.swing.GroupLayout prizeView2Layout = new javax.swing.GroupLayout(prizeView2);
        prizeView2.setLayout(prizeView2Layout);
        prizeView2Layout.setHorizontalGroup(
            prizeView2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        prizeView2Layout.setVerticalGroup(
            prizeView2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        Nivel.setBackground(new java.awt.Color(0, 0, 0));
        Nivel.setFont(new java.awt.Font("Tahoma", 0, 35)); // NOI18N
        Nivel.setText("Lvl");
        Nivel.setToolTipText("");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(Titulo, javax.swing.GroupLayout.PREFERRED_SIZE, 281, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(Nivel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(badConsequenceView2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(prizeView2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Titulo, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Nivel))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(badConsequenceView2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(prizeView2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Nivel;
    private javax.swing.JLabel Titulo;
    private GUI.BadConsequenceView badConsequenceView2;
    private GUI.PrizeView prizeView2;
    // End of variables declaration//GEN-END:variables
}
