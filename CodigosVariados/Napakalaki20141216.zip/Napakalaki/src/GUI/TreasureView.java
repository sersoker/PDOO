package GUI;

import NapakalakiGame.Treasure;


public class TreasureView extends javax.swing.JPanel {
    Treasure treasureModel;

    public TreasureView() {
        initComponents();
    }
    public void setTreasure (Treasure t) {
        treasureModel = t;
        
        Titulo.setText(treasureModel.getName());
        BonusMinimo.setText(Integer.toString(treasureModel.getMinBonus()));
        BonusMaximo.setText(Integer.toString(treasureModel.getMaxBonus()));
        Monedas.setText(Integer.toString(treasureModel.getGoldCoins()));
        Tipo.setText(treasureModel.getType().toString());

        revalidate();
        repaint();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Titulo = new javax.swing.JLabel();
        BonusMinimo = new javax.swing.JLabel();
        Monedas = new javax.swing.JLabel();
        Tipo = new javax.swing.JLabel();
        BonusMaximo = new javax.swing.JLabel();

        Titulo.setText("Titulo");

        BonusMinimo.setText("BonusMinimo");

        Monedas.setText("Monedas");

        Tipo.setText("Tipo");

        BonusMaximo.setText("BonusMaximo");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(Titulo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(BonusMinimo)
                            .addComponent(Monedas)
                            .addComponent(Tipo)
                            .addComponent(BonusMaximo))
                        .addGap(0, 138, Short.MAX_VALUE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(Titulo, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30)
                .addComponent(BonusMinimo)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(BonusMaximo)
                .addGap(40, 40, 40)
                .addComponent(Monedas)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 34, Short.MAX_VALUE)
                .addComponent(Tipo)
                .addContainerGap())
        );
    }// </editor-fold>//GEN-END:initComponents


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel BonusMaximo;
    private javax.swing.JLabel BonusMinimo;
    private javax.swing.JLabel Monedas;
    private javax.swing.JLabel Tipo;
    private javax.swing.JLabel Titulo;
    // End of variables declaration//GEN-END:variables
}
