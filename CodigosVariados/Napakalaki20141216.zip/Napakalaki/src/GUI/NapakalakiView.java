package GUI;
import NapakalakiGame.Napakalaki;

public class NapakalakiView extends javax.swing.JFrame {
    
    private Napakalaki napakalakiModel;
    
    public void setNapakalaki(Napakalaki nap){
       napakalakiModel=nap;
       repaint();
       revalidate();
    }
    

    /** Creates new form NapakalakiView */
    public NapakalakiView() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        playerView1 = new GUI.PlayerView();
        monsterView1 = new GUI.MonsterView();
        resultado = new javax.swing.JLabel();
        Informacion = new javax.swing.JLabel();
        MeetMonster = new javax.swing.JButton();
        Combat = new javax.swing.JButton();
        NextTurn = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        playerView1.setBorder(javax.swing.BorderFactory.createTitledBorder("Jugador"));

        monsterView1.setBorder(javax.swing.BorderFactory.createTitledBorder("Monstruo"));

        resultado.setText("ResultadoDeCombate");

        Informacion.setText("Otra Informacion");

        MeetMonster.setText("Meet The Monster");

        Combat.setText("Combat");

        NextTurn.setText("Next Turn");

        org.jdesktop.layout.GroupLayout layout = new org.jdesktop.layout.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(layout.createSequentialGroup()
                .add(playerView1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 364, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(monsterView1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
            .add(layout.createSequentialGroup()
                .addContainerGap()
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(Informacion, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 354, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(resultado, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 354, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .add(18, 18, 18)
                .add(MeetMonster)
                .add(32, 32, 32)
                .add(Combat)
                .add(39, 39, 39)
                .add(NextTurn))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(layout.createSequentialGroup()
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING, false)
                    .add(org.jdesktop.layout.GroupLayout.LEADING, monsterView1, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 310, Short.MAX_VALUE)
                    .add(org.jdesktop.layout.GroupLayout.LEADING, playerView1, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(layout.createSequentialGroup()
                        .add(resultado, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 25, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .add(1, 1, 1)
                        .add(Informacion, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 25, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap())
                    .add(org.jdesktop.layout.GroupLayout.TRAILING, layout.createSequentialGroup()
                        .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                            .add(MeetMonster)
                            .add(Combat)
                            .add(NextTurn))
                        .add(23, 23, 23))))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    public void showView(){
        this.setVisible(true);
    }
    
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Combat;
    private javax.swing.JLabel Informacion;
    private javax.swing.JButton MeetMonster;
    private javax.swing.JButton NextTurn;
    private GUI.MonsterView monsterView1;
    private GUI.PlayerView playerView1;
    private javax.swing.JLabel resultado;
    // End of variables declaration//GEN-END:variables
}
