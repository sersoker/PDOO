## To change this license header, choose License Headers in Project Properties.
# To change this template file, choose Tools | Templates
# and open the template in the editor.

class BadConsequence
  def initialize(aText=nil, someLevels=0, someVisibleTreasures=0, 
    someHiddenTreasures=0, someSpecificVisibleTreasures=Array.new(), 
    someSpecificHiddenTreasures=Array.new(), death=false) 
  
    @text=aText
    @levels=someLevels
    @nVisibleTreasures=someVisibleTreasures
    @nHiddenTreasures=someHiddenTreasures
    @specificVisibleTreasures=someSpecificVisibleTreasures
    @specificHiddenTreasures=someSpecificHiddenTreasures
    @death=death
    
  end
  
  def self.newLevelNumberOfTreasures (aText, someLevels, 
    someVisibleTreasures, someHiddenTreasures)
    new(aText,someLevels,someVisibleTreasures,someHiddenTreasures)
  end
  
  def self.newLevelSpecificTreasures (aText, someLevels,        
    someSpecificVisibleTreasures, someSpecificHiddenTreasures)
    new(aText,someLevels,0,0,someSpecificVisibleTreasures,someSpecificHiddenTreasures)
  end
  
  def self.newDeath (aText)
    new(aText,0,0,0,Array.new(),Array.new(),true)
  end
  
private_class_method :new

attr_reader:levels
attr_reader:text

  def to_s
  "Descripcion: #{@text} \n Niveles perdidos: #{@levels} \n
  Tesoros visibles perdidos: #{@nVisibleTreasures} \n  
  Tesoros ocultos perdidos: #{@nHiddenTreasures}\n
  Muerte: #{@death}"
  end
  
end
