# To change this license header, choose License Headers in Project Properties.
# To change this template file, choose Tools | Templates
# and open the template in the editor.

class Monster

  def initialize(nombre=nil,nivelCombate=nil,prize=nil,bc=nil)
    @name=nombre
    @combatLevel=nivelCombate
    @prize=prize
    @bc=bc
  end
  
  attr_reader:name
  attr_reader:combatLevel
  
  def to_s
    "Nombre: #{@name} \n Nivel de Combate: #{@combatLevel}\n"
  end
  
  def consecuencia
    @bc.levels
  end
  
  def gananivel
    @prize.level 
  end
 
end
