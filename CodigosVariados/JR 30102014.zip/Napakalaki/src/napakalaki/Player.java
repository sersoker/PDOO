package napakalaki;

import java.util.ArrayList;

/**
 *
 * @author sersoker
 */
public class Player {
    private boolean dead;
    private String name;
    private int level;

    public Player(String name) {
        this.name = name;
        this.level= 1;
        this.dead = true;
    }
    
    private void bringToLife(){
    
    }
    
    private int getCombatLevel(){
        return 1;
    }
    
    private void incrementLevel(int i){
    
    }
   
    private void decrementLevel(int i){
    
    }
    
    private void setPendingBadConsequence(BadConsequence b){
    
    }
    
    private void dielfNoTreasures(){
    
    }
    
    private void discardNecklacelfVisible(){
    
    
    }
    
    private void die (){
    
    }

    private int computeGoldCoinsValue(Treasure t){
        return 1;
    }

    private boolean canIBuyLevels(int i){
        return true;
    
    }

    private void applyPrize(Monster currentMonster){
    
    
    }
    
    private void applyBadConsequence(BadConsequence b){
    
    }

    private boolean canMakeTreasureVisible(Treasure t){
        return true;
    }

    private int howManyVisibleTreasures(TreasureKind tKind){
        return 1;
    }
    
    boolean isDead(){
        return true;
    }
    
    public ArrayList<Treasure> getHiddenTreasures(){
        return new ArrayList();
    
    }
    
    public ArrayList<Treasure> getVisibleTreasures(){
        return new ArrayList();
    
    }
    
//    public CombatResult combat (Monster m){
//       
//    }
//    

    public void makeTreasureVisible(Treasure t){
    
    }
    
    public void discardVisibleTreasure(Treasure t){
    
    }
    
    public void discarHiddenTreasure(Treasure t){
    
    }
    
    public boolean buyLevels(ArrayList<Treasure> visible, ArrayList<Treasure> hidden ){
        return true;
    }
    
    public boolean validState(){
        return true;
    }
    
    public void initTreasures(){
    
    }
    
    public boolean hasVisibleTreasures(){
        return true;
    }
    
    public int getlevels(){
        return 1;
    }
    
}













