package napakalaki;

import java.util.ArrayList;

public class CardDealer {
    private static final CardDealer INSTANCE = null;
    private ArrayList <Treasure> unusedTreasures=new ArrayList();
    private ArrayList <Treasure> usedTreasures=new ArrayList();
    private ArrayList <Treasure> unusedMonsters=new ArrayList();
    private ArrayList <Treasure> usedMonsters=new ArrayList();
    
    private CardDealer() {
    }
    
    private static class CardDealerHolder {

        private static final CardDealer INSTANCE = new CardDealer();
    }
    
    private void initTreasuresCardDeck(){
    
    }
    
    private void initMonsterCardDeck(){
    
    }
    
    private void shuffleTreasures(){
    
    }
    
    private void shuffleMonsters(){
    
    }
    
    public static CardDealer getInstance() {
        return CardDealerHolder.INSTANCE;
    }
    
    public Treasure nextTreasure(){
            return null; 
    }
    
    public Monster nextMonster(){
        return null; 
    }
    
    public void giveTreasureBack(Treasure t){
    
    }
    
    public void giveMonsterBack(Monster m){
    
    }
    
    public void initCards(){
    
    }
    
}
