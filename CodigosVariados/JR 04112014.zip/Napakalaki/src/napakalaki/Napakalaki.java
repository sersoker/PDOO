package napakalaki;

import java.util.ArrayList;

public class Napakalaki {
    
    private static final Napakalaki instance = null;
    private CombatResult combatResult;
    private Player currentPlayer;
    private ArrayList <Player> Players = new ArrayList();
    private CardDealer dealer;
    private Monster currentMonster;
    
    private Napakalaki() {
    }
    
    private void initPlayers(ArrayList<String> names){
    
    }
    
    private Player nextPlayer(){
            return null; 
    }
  
    private boolean nextTurnAllowed(){
        return false;
    }
    
    public Napakalaki getInstance (){
        return instance;
    }
    
    public CombatResult developCombat (){
        return CombatResult.Win;
    }
    
    public void discardVisibleTreasures (ArrayList<Treasure> treasures){
        
    }

    public void discardHiddenTreasures (ArrayList<Treasure> treasures){
        
    }

    public void makeTreasuresVisible(ArrayList<Treasure> treasures){
        
    }
    
    public boolean buyLevels(ArrayList<Treasure> visible, ArrayList<Treasure> hidden){
        return true;
    }
   

    public void initGame( ArrayList<String> players ){
        
    }

    public Player getCurrentPlayer(){
            return null; 
    }
  
    public Monster getCurrentMonster(){
        return null; 
    }
    
    public boolean nextTurn(){
        return false;
    }
    
    public boolean endOfGame( CombatResult result ){
        return false;
    }
    
}
