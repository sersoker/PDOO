
package napakalaki;

public class Dice {
    
    private static final Dice instance = null;
    
    private Dice() {
    }
    
    public static Dice getInstance() {
        return instance;
    }
    
    public static int nextNumber(){
        return 1;
    }
    
}
