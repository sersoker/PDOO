 package napakalaki;

public enum TreasureKind {
  armor,oneHand,bothHand,helmet,shoe,necklace;
}
