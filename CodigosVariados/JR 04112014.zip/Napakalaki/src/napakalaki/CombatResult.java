package napakalaki;

public enum CombatResult {
    WinAndWinGame,
    Win,
    Lose,
    LoseAndEscape,
    LoseAndDie;
}
