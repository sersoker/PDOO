module NapakalakiGame
  class Player
    @pendingBadConsequence;
    @dice;
    @cardDealer;
    @combatResult;
    @hiddenTreasures;
    @visibleTreasures;
    
    def initialize(name)
      @name=name
      @level=1
      @dead=true
    end
    
    #preguntar alcance de private
    private 
    
    def bringToLife()
      
    end
    
    attr_reader:level
   
    def incrementLevel(i)
      
    end
    
    def decrementLevel(i)
      
    end
    
    def setPendingBadConsequence(b)
      
    end
    
    def dieIfNoTreasures
      
    end
    
    def discardNecklaceVisible
      
    end
    
    def die
      
    end
    
    def computeGoldCoinsValue(t)
      
    end
    
    def canIBuyLevels(i)
      
    end
    
    def applyPrize(currentMonster)
      
    end
    
    def applyBadConsequence(bad)
      
    end
    
    def canMakeTreasureVisible(t)
      
    end
    
    def howManyVisibleTreasures(tKind)
      
    end
    
    #preguntar alcance de nuevo
    public 
    def isDeath
      return @death
    end
    
    def getHiddenTreasures
      
    end
    
    def getVisibleTreasures
      
    end
    
    def combat(m)
      
    end
    
    def makeTreasureVisible(t)
      
    end
    
    def discardVisibleTreasure(t)
      
    end
  
    def discardHiddenTreasure(t)
      
    end
    
    def buyLevels(visible,hidden)
            
    end
    
    def validState
      
    end
    
    def initTreasures
      
    end
  
    def hasVisibleTreasures
     
    end
    
    def getLevels
      
    end
  
  end
end
