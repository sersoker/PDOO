module NapakalakiGame
  class CardDealer
    include Singleton

    @@CardDealer.instance=nil
    @unusedTreasures;
    @usedTreasures;
    @unusedMonsters;
    @usedMonsters;
    

    private 
    def inialize

    end

    def initTreasureCardDeck

    end

    def initMonsterCardDeck

    end

    def shuffleTreasure

    end

    def shuffleMonsters

    end


    public 
    def self.getInstance
      return @@CardDealer
    end

    def nextTreasure

    end

    def nextMonster

    end  

    def giveTreasureBack(t)

    end

    def giveMonsterBack(m)

    end

    def initCards

    end

  end
end
