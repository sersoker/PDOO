module NapakalakiGame
class Dice
  include Singleton
  
  @@Dice.instance=nil
  
  private 
  def inialize
    
  end
  
  public 
  def self.getInstance
    return @@Dice
  end
  
  public 
  def nextNumber
    
  end
  
end
end
