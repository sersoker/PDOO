module NapakalakiGame
  module CombatResult
      WinAndWinGame="WinAndWinGame"
      Win="Win"
      Lose="Lose"
      LoseAndEscape="LoseAndEscape"
      LoseAndDie="LoseAndDie"
   end
end