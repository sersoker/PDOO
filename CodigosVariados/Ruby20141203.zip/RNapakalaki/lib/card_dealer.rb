# encoding: utf-8 
require "singleton"
require_relative "treasure"
require_relative "treasure_kind"
require_relative "prize"
require_relative "bad_consequence"
require_relative "monster"

module Napakalaki
  class CardDealer
    include Singleton

    def initialize
    @unusedMonsters=Array.new()
    @usedMonsters=Array.new()
    @unusedTreasures=Array.new()
    @usedTreasures=Array.new()
    end
def initTreasureCardDeck

      @unusedTreasures.push(Treasure.new("¡Si mi amo!",0,4,7,[TreasureKind::HELMET]))
      @unusedTreasures.push(Treasure.new("Botas de investigacion",600,3,4,[TreasureKind::SHOE]))
      @unusedTreasures.push(Treasure.new("Capucha de Cthulhu",500,3,5,[TreasureKind::HELMET]))
      @unusedTreasures.push(Treasure.new("A prueba de babas",400,2,5,[TreasureKind::ARMOR]))
      @unusedTreasures.push(Treasure.new("Botas de lluvia acida",800,1,1,[TreasureKind::BOTHHAND]))
      @unusedTreasures.push(Treasure.new("Casco minero",400,2,4,[TreasureKind::HELMET]))
      @unusedTreasures.push(Treasure.new("Ametralladora Thompson",600,4,8,[TreasureKind::BOTHHAND]))
      @unusedTreasures.push(Treasure.new("Camiseta de la UGR",100,1,7,[TreasureKind::ARMOR]))
      @unusedTreasures.push(Treasure.new("Clavo de rail ferroviario",400,3,6,[TreasureKind::ONEHAND]))
      @unusedTreasures.push(Treasure.new("Cuchillo de sushi arcano",300,2,3,[TreasureKind::ONEHAND]))
      @unusedTreasures.push(Treasure.new("Fez alopodo",700,3,5,[TreasureKind::HELMET]))
      @unusedTreasures.push(Treasure.new("Hacha prehistorica",500,2,5,[TreasureKind::ONEHAND]))
      @unusedTreasures.push(Treasure.new("El aparato del Pr. Tesla",900,4,8,[TreasureKind::ARMOR]))
      @unusedTreasures.push(Treasure.new("Gaita",500,4,5,[TreasureKind::BOTHHAND]))
      @unusedTreasures.push(Treasure.new("Insecticida",300,2,3,[TreasureKind::ONEHAND]))
      @unusedTreasures.push(Treasure.new("Escopeta de 3 cañones",700,4,6,[TreasureKind::BOTHHAND]))
      @unusedTreasures.push(Treasure.new("Garabato mistico",300,2,2,[TreasureKind::ONEHAND]))
      @unusedTreasures.push(Treasure.new("La fuerza de Mr. T",1000,10,10,[TreasureKind::NECKLACE]))
      @unusedTreasures.push(Treasure.new("La rebeca metalica",400,2,3,[TreasureKind::ARMOR]))
      @unusedTreasures.push(Treasure.new("Mazo de los antiguos",200,3,4,[TreasureKind::ONEHAND]))
      @unusedTreasures.push(Treasure.new("Necroplayboycon",300,3,5,[TreasureKind::ONEHAND]))
      @unusedTreasures.push(Treasure.new("Lanzallamas",800,4,8,[TreasureKind::BOTHHAND]))
      @unusedTreasures.push(Treasure.new("Necrocomicon",100,1,1,[TreasureKind::ONEHAND]))
      @unusedTreasures.push(Treasure.new("Necronomicon",800,5,7,[TreasureKind::BOTHHAND]))
      @unusedTreasures.push(Treasure.new("Linterna a 2 manos",400,3,6,[TreasureKind::BOTHHAND]))
      @unusedTreasures.push(Treasure.new("Necrognomicon",200,2,4,[TreasureKind::ONEHAND]))
      @unusedTreasures.push(Treasure.new("Necrotelecom",300,2,3,[TreasureKind::HELMET]))
      @unusedTreasures.push(Treasure.new("Porra preternatural",200,2,3,[TreasureKind::ONEHAND]))
      @unusedTreasures.push(Treasure.new("Tentaculo de pega",200,0,1,[TreasureKind::HELMET]))
      @unusedTreasures.push(Treasure.new("Zapato deja-amigos",500,0,1,[TreasureKind::SHOE]))
      @unusedTreasures.push(Treasure.new("Shogulador",600,1,1,[TreasureKind::BOTHHAND]))
      @unusedTreasures.push(Treasure.new("Varita de atizamiento",400,3,4,[TreasureKind::ONEHAND]))
    end

    def initMonsterCardDeck

      price=Prize.new(2,1)
      badc=BadConsequence.newLevelSpecificTreasures("Pierdes tu armadura visible y otra oculta",0,[TreasureKind::ARMOR],[TreasureKind::ARMOR])
      monstruo=Monster.new("3 Byakhees de bonanza",8,price,badc)
       @unusedMonsters.push(monstruo)

      price=Prize.new(1,1)
      badc=BadConsequence.newLevelSpecificTreasures("Embobados con el lindo primigenio te descartas de tu casco visible",0,[TreasureKind::HELMET],[])
      monstruo=Monster.new("Chibithulhu",2,price,badc)
       @unusedMonsters.push(monstruo)

      price=Prize.new(1,1)
      badc=BadConsequence.newLevelSpecificTreasures("El primordial bostezo contagioso. Pierdes el calzado visible",0,[TreasureKind::SHOE],[])
      monstruo=Monster.new("El sopor de Dunwich",2,price,badc)
       @unusedMonsters.push(monstruo)

      price=Prize.new(4,1)
      badc=BadConsequence.newLevelSpecificTreasures("Te atrapan para llevarte de fiesta y te dejan caer en mitad del vuelo. Descarta 1 mano visible y 1 mano oculta",0,[TreasureKind::HAND],[TreasureKind::HAND])
      monstruo=Monster.new("Angeles de la noche ibicenca",14,price,badc)
       @unusedMonsters.push(monstruo)

      price=Prize.new(3,1)
      badc=BadConsequence.newLevelNumberOfTreasures("Pierdes todos tus tesoros visibles",0,6,0)
      monstruo=Monster.new("El gorron en elumbral",10,price,badc)
       @unusedMonsters.push(monstruo)

      price=Prize.new(2,1)
      badc=BadConsequence.newLevelSpecificTreasures("Pierdes la armadura visible",0,[TreasureKind::ARMOR],[])
      monstruo=Monster.new("H.P.Munchcraft",6,price,badc)
       @unusedMonsters.push(monstruo)

      price=Prize.new(1,1)
      badc=BadConsequence.newLevelSpecificTreasures("Sientes bichos bajo la ropa. Descarta la armadura visible",0,[TreasureKind::ARMOR],[])
      monstruo=Monster.new("Bichgooth",2,price,badc)
       @unusedMonsters.push(monstruo)

      price=Prize.new(4,2)
      badc=BadConsequence.newLevelNumberOfTreasures("Pierdes 5 niveles y 3 tesoros visibles.",5,3,0)
      monstruo=Monster.new("El rey de rosa",13,price,badc)
       @unusedMonsters.push(monstruo)

      price=Prize.new(1,1)
      badc=BadConsequence.newLevelNumberOfTreasures("Toses los pulmones ypierdes 2 niveles.",2,0,0)
      monstruo=Monster.new("La que redacta en las tinieblas",2,price,badc)
       @unusedMonsters.push(monstruo)

      price=Prize.new(2,1)
      badc=BadConsequence.newDeath("Estos monstruos resultan bastante superciales y te aburren mortalmente. Estas muerto")
      monstruo=Monster.new("Los hondos",8,price,badc)
       @unusedMonsters.push(monstruo)

      price=Prize.new(2,1)
      badc=BadConsequence.newLevelNumberOfTreasures("Pierdes 2 niveles y 2 tesoros oculto",2,0,2)
      monstruo=Monster.new("Semillas Cthulhu",4,price,badc)
       @unusedMonsters.push(monstruo)

      price=Prize.new(2,1)
      badc=BadConsequence.newLevelSpecificTreasures("Te intentas escaquear.Pierdes una mano visible.",0,[TreasureKind::HAND],[])
      monstruo=Monster.new("Dameargo",1,price,badc)
       @unusedMonsters.push(monstruo)

      price=Prize.new(1,1)
      badc=BadConsequence.newLevelNumberOfTreasures("Da mucho asquito. Pierdes 3 niveles.",3,0,0)
      monstruo=Monster.new("Pollipolipo volante",3,price,badc)
       @unusedMonsters.push(monstruo)

      price=Prize.new(3,1)
      badc=BadConsequence.newDeath("No le hace gracia que pronuncien mal su nombre. Estas muerto")
      monstruo=Monster.new("Yskhtihyssg-Goth",12,price,badc)
       @unusedMonsters.push(monstruo)


      price=Prize.new(4,1)
      badc=BadConsequence.newDeath("La familia te atrapa. Estas muerto.")
      monstruo=Monster.new("La familia feliz",1,price,badc)
       @unusedMonsters.push(monstruo)

      price=Prize.new(2,1)
      badc=BadConsequence.newLevelSpecificTreasures("La quinta directiva primaria te obliga a perder 2 niveles y un tesoro 2 manos visible",2,[TreasureKind::BOTHHAND],[])
      monstruo=Monster.new("Roboggoth",8,price,badc)
       @unusedMonsters.push(monstruo)

      price=Prize.new(1,1)
      badc=BadConsequence.newLevelSpecificTreasures("Te asusta en la noche. Pierdes un casco visible",0,[TreasureKind::HELMET],[])
      monstruo=Monster.new("El espia",5,price,badc)
       @unusedMonsters.push(monstruo)

      price=Prize.new(1,1)
      badc=BadConsequence.newLevelNumberOfTreasures("Menudo susto te llevas. Pierdes 2 niveles y 5 tesoros visibles.",2,5,0)
      monstruo=Monster.new("El lenguas",20,price,badc)
       @unusedMonsters.push(monstruo)

      price=Prize.new(1,1)
      badc=BadConsequence.newLevelNumberOfTreasures("Te faltan manos para tanta cabeza. Pierdes 3 niveles y tus tesoros visibles de las manos.",3,6,0)
      monstruo=Monster.new("efalo",20,price,badc)
       @unusedMonsters.push(monstruo)


    end

    def shuffleTreasures
      @unusedTreasures=@unusedTreasures.shuffle
    end

    def shuffleMonsters
      @unusedMonsters=@unusedMonsters.shuffle
    end


    public 

    def nextTreasure
      if @unusedTreasures.empty?
        @unusedTreasures = @usedTreasures
        @usedTreasures.clear
        shuffleTreasures
      end
      tesoro = @unusedTreasures.at(0)
      @unusedTreasures.delete(tesoro)
      tesoro
    end

    def nextMonster
      if @unusedMonsters.empty?
        @unusedMonsters = @usedMonsters
        @usedMonsters.clear
        shuffleMonsters
      end
      monstruo = @unusedMonsters.at(0)
      @unusedMonsters.delete(monstruo)
      monstruo
    end  

    def giveTreasureBack(t)
      @usedTreasures.push(t)

    end

    def giveMonsterBack(m)
      @usedMonsters.push(m)
    end

    def initCards
      initTreasureCardDeck
      shuffleTreasures  
      initMonsterCardDeck
      shuffleMonsters   
    end

  end
end
