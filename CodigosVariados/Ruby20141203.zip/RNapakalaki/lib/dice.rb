module Napakalaki
class Dice
  include Singleton

  public 
  def nextNumber
    return rand(6)+1
  end
  
end
end
