module Napakalaki
  module TreasureKind
      HAND="HAND"
      ONEHAND="ONEHAND"
      ARMOR="ARMOR"
      BOTHHAND="BOTHHAND"
      HELMET="HELMET"
      SHOE="SHOE"
      NECKLACE="NECKLACE"    
  end
end