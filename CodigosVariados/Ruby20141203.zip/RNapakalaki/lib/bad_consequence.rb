module Napakalaki
class BadConsequence
  def initialize(aText=nil, someLevels=0, someVisibleTreasures=0, 
    someHiddenTreasures=0, someSpecificVisibleTreasures=Array.new(), 
    someSpecificHiddenTreasures=Array.new(), death=false) 
  
    @text=aText
    @levels=someLevels
    @nVisibleTreasures=someVisibleTreasures
    @nHiddenTreasures=someHiddenTreasures
    @specificVisibleTreasures=someSpecificVisibleTreasures
    @specificHiddenTreasures=someSpecificHiddenTreasures
    @death=death
    
  end
  
  def self.newLevelNumberOfTreasures (aText, someLevels, 
    someVisibleTreasures, someHiddenTreasures)
    new(aText,someLevels,someVisibleTreasures,someHiddenTreasures)
  end
  
  def self.newLevelSpecificTreasures (aText, someLevels,        
    someSpecificVisibleTreasures, someSpecificHiddenTreasures)
    new(aText,someLevels,0,0,someSpecificVisibleTreasures,someSpecificHiddenTreasures)
  end
  
  def self.newDeath (aText)
    new(aText,0,0,0,Array.new(),Array.new(),true)
  end
  
private_class_method :new

attr_reader:levels
attr_reader:text
attr_reader:nVisibleTreasures
attr_reader:nHiddenTreasures
attr_reader:specificVisibleTreasures
attr_reader:specificHiddenTreasures

  def to_s
  "Descripcion: #{@text} \n Niveles perdidos: #{@levels} \n
  Tesoros visibles perdidos: #{@nVisibleTreasures} \n  
  Tesoros ocultos perdidos: #{@nHiddenTreasures}\n
  Muerte: #{@death}"
  end
  
  public 
  
  def isEmpty
    if @levels==0&&@nVisibleTreasures==0&&@nHiddenTreasures==0&&@specificVisibleTreasures.empty?&&@specificHiddenTreasures.empty?&&!@death
    return true 
    end
    return false
  end
  
  def substractVisibleTreasure(t)
    encontrado = false
    i=0
    while (i<@specificVisibleTreasures.size-1 && !encontrado)
      if t.type == @specificVisibleTreasures[i]
        encontrado = true
        @specificVisibleTreasures.delete(i)
      end
      i=i+1
    end
    if !encontrado
      @nVisibleTreasures = @nVisibleTreasures - 1
    end
  end
  
  def substractHiddenTreasure(t)
    encontrado = false
    i=0
    while(i<@specificHiddenTreasures.size-1 && !encontrado)
      if t.type == @specificHiddenTreasures[i]
        encontrado = true
        @specificHiddenTreasures.delete(i)
      end
      i=i+1
    end
    if !encontrado
      @nHiddenTreasures = @nHiddenTreasures - 1 
    end    
  end
  
 
  def adjustToFitTreasure(v,h)
    if @death
      bs = BadConsequence.newDeath(@text)
      return bs
    end 

    vusu=v.size
    husu=h.size
    
    if @nVisibleTreasures>0||@nHiddenTreasures>0
      if vusu>=@nVisibleTreasures
        vdevuelve=@nVisibleTreasures
      else
        vdevuelve=vusu
      end
      
      if husu>=@nHiddenTreasures
        hdevuelve=@nHiddenTreasures
      else
        hdevuelve=husu
      end
      
      bs = BadConsequence.newLevelNumberOfTreasures(@text,0,vdevuelve,hdevuelve)

      return bs
    else
        t_visible = Array.new
        t_hidden = Array.new
        
        v.each do |t|
          @specificVisibleTreasures.each do |j|
            if j == t.type
                t_visible << t.type
            end
          end
        end
        
        h.each do |t|
          @specificVisibleTreasures.each do |i|
            if i == t.type
                t_hidden << t.type
            end
          end
        end

         bs = BadConsequence.newLevelSpecificTreasures(@text,0, t_visible, t_hidden)

        return bs
    end   
    
  end
  
  def myBadConsequenceIsDeath
    return @death;
  end
  
end


end
