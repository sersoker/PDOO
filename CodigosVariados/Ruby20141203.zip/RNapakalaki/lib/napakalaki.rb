require "singleton"
require_relative "monster"
require_relative "player"
require_relative "treasure"
require_relative "combat_result"
require_relative "card_dealer"
module Napakalaki
  class Napakalaki
    
    include Singleton


    def initialize
      @players=Array.new
      @dealer=CardDealer.instance 
      @currentPlayer=nil
    end
  private 

    def initPlayers(names)
      names.each do |p|
        jugador=Player.new(p)
        @players.push(jugador)
      end
    end

    
    def nextPlayer
      if @currentPlayer!=nil
        for i in 0..@players.size
          if @players.at(i)==@currentPlayer
            return @players.at((i+1)%@players.size)
          end
        end   
      end
     aleatorio=rand(@players.size)
     return @players.at(aleatorio)      
    end

    def nextTurnAllowed
    if @currentPlayer==nil
        return true
    else
       return @currentPlayer.validState
    end
      
    end

    
    public 

    def developCombat
      combatResult = @currentPlayer.combat(@currentMonster)
      @dealer.giveMonsterBack(@currentMonster)
      return combatResult
    end

    def discardVisibleTreasures(treasures)
       treasures.each do |treasure|
         @currentPlayer.discardVisibleTreasure(treasure)
         @dealer.giveTreasureBack(treasure)
       end
    end  
    
    def discardHiddenTreasures(treasures)
       treasures.each do |treasure|
         @currentPlayer.discardHiddenTreasure(treasure)
         @dealer.giveTreasureBack(treasure)
       end
    end

    def makeTreasuresVisible(treasures)
      treasures.each do |t|
          @currentPlayer.makeTreasureVisible(t)
      end
    end
    
    def buyLevels(visible,hidden)
      canI=@currentPlayer.buyLevels(visible, hidden)
      canI
    end
    
    def initGame(players)
      initPlayers(players)
      @dealer.initCards
      nextTurn
    end
  
    def getCurrentPlayer()
      return @currentPlayer      
    end
  
    def getCurrentMonster()
      return @currentMonster
    end
    
    def nextTurn
      stateOK = nextTurnAllowed
      if  stateOK 
        @currentMonster = @dealer.nextMonster
        @currentPlayer = nextPlayer
        dead=@currentPlayer.isDead
        if(dead)
          @currentPlayer.initTreasures
        end
      end
      return stateOK
    end
    
    def endOfGame(result)
      return if result==[CombatResult::WinAndWinGame]
    end
    
  end
end
