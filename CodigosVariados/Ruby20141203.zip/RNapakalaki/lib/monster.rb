module Napakalaki
  class Monster

    def initialize(nombre=nil,nivelCombate=nil,prize=nil,bc=nil)
      @name=nombre
      @combatLevel=nivelCombate
      @prize=prize
      @badConsequence=bc
    end

    attr_reader:name,:combatLevel,:badConsequence,:prize

    def to_s
      "Nombre: #{@name} \n Nivel de Combate: #{@combatLevel}\n"
    end

    def consecuencia
      @bc.levels
    end

    def gananivel
      @prize.level 
    end
    
    def getLevelsGained
      return @prize.levels
    end
    
    def getTreasuresGained
      return @prize.treasures
      
    end
    
    def kills
      return @badConsequence.myBadConsequenceIsDeath
      
    end
    
    
  end
end