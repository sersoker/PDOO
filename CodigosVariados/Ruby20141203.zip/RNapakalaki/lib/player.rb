require_relative "treasure"
require_relative "bad_consequence"
require_relative "treasure_kind"
require_relative "card_dealer"
require_relative "dice"
require_relative "combat_result"

module Napakalaki
  class Player
    
    def initialize(name)
      @name=name
      @level=1
      @dead=true
      @hiddenTreasures= Array.new
      @visibleTreasures = Array.new
    end
    
    attr_reader:level
    attr_reader:pendingBadConsequence
    #preguntar alcance de private
    private 
    
    def bringToLife
      @dead=false      
    end
    
    def cuentaNV
       nivel=0
     #/boolean contenido=visibleTreasure.contains(collar)
      contenido=false
      if !contenido
        @visibleTreasures.each do |t|
            nivel=nivel+t.minBonus
        end
      else
        @visibleTreasures.each do |t|
            nivel=nivel+t.maxBonus
        end
        
      end
      return nivel
    end
    
    def getCombatLevel
      return level+cuentaNV()
    end
   
    def incrementLevels(i)
        @level=@level+i
      end
      
    
    def decrementLevels(i)
      if ((@level-i)<=0)
        die
      else
        @level=@level-i
      end
    end 
    
    def setPendingBadConsequence(b)
      @pendingBadConsequence=b
      
    end
    
    def dieIfNoTreasures
      if @hiddenTreasures.empty? && @visibleTreasures.empty?
         @dead=true
      end
    end
    
    def discardNecklaceIfVisible
      @visibleTreasures.each do |t|
                if t.type==[TreasureKind::NECKLACE]
                    @visibleTreasures.delete(t);
                    CardDealer.instance.giveTreasureBack(t)
                end
      end
    end
    
    def die
      @level=1
      dealer=CardDealer.instance
      @visibleTreasures.each do |treasure|
        dealer.giveTreasureBack(treasure)
      end
      @visibleTreasures.clear
      @hiddenTreasures.each do |treasure|
        dealer.giveTreasureBack(treasure)
      end
      @hiddenTreasures.clear
      dieIfNoTreasures
    end
    
    def computeGoldCoinsValue(t)
    monedas=0
        t.each do |m|
            monedas+=m.goldCoins
        end
     return monedas
     end
    
    def canIBuyLevels(i)
      if level+i>=10
        return false
      end
      return true
    end
    
    def applyPrize(currentMonster)
      nLevels=currentMonster.getLevelsGained
      incrementLevels(nLevels)
      nTreasures=currentMonster.getTreasuresGained
      if(nTreasures>0)
        dealer=CardDealer.instance
        for i in 0..nTreasures
          treasure=dealer.nextTreasure
          @hiddenTreasures.push(treasure)
        end
      end
    end
    
    def applyBadConsequence(bad)
      nLevels=bad.levels
      decrementLevels(nLevels)
      pendingBad=bad.adjustToFitTreasure(@visibleTreasures, @hiddenTreasures)
      setPendingBadConsequence(pendingBad)
    end

    def canMakeTreasureVisible(t)
      if (t.type==[TreasureKind::ONEHAND]||t.type==[TreasureKind::BOTHHAND])
          @visibleTreasures.each do |te|
            if (te.type==[TreasureKind::BOTHHAND])
              return false
            end      
          end
      end
      if (t.type==[TreasureKind::BOTHHAND])
        @visibleTreasures.each do |te|
          if(te.type==[TreasureKind::ONEHAND])
            return false
          end
        end
      end
      if (t.type==[TreasureKind::ONEHAND])
        tengo=0
        @visibleTreasures.each do |te|
          if (te.type==[TreasureKind::ONEHAND])
            tengo=tengo+1
          end
        end
        if (tengo<=1)
          return true
        else
          return false
        end
      end
      @visibleTreasures.each do |te|
        if(t.type==te.type)
          return false
        end
      end
      return true
    end

    def howManyVisibleTreasures(tKind)
        cuantos=0;
        visibleTreasures.each do |t|
          if t.type==tKind
                   cuantos=cuantos+1
        return cuantos
      
           end
        end
    end
    

    public 
    def to_s
      "Nombre: #{@name} \n Nivel: #{@level}"
    end
    
    def isDead
      return @dead
    end
    
    def getHiddenTreasures
      return @hiddenTreasures
    end
    
    def getVisibleTreasures
      return @visibleTreasures
    end
    
    def combat(m)
      myLevel = getCombatLevel
      monsterLevel = m.combatLevel
      if (myLevel>monsterLevel)
        applyPrize(m)
        if (@level>=10)
          combatResult = CombatResult::WINANDWINGAME
        else
          combatResult = CombatResult::WIN
        end
      else
        dice = Dice.instance
        escape = dice.nextNumber
        if (escape<5)
          amIDead = m.kills
          if (amIDead)
            die
            combatResult=CombatResult::LOSEANDDIE
          else
            bad=m.badConsequence
            combatResult=CombatResult::LOSE
            applyBadConsequence(bad)
          end
        else
          combatResult=CombatResult::LOSEANDESCAPE
        end
      
        
      end
      discardNecklaceIfVisible
      return combatResult
      
    end
    
    def makeTreasureVisible(t)
      canI=canMakeTreasureVisible(t)
      if(canI)
        @visibleTreasures.push(t)
        @hiddenTreasures.delete(t)
      end
    end
    
    def discardVisibleTreasure(t)
      @visibleTreasures.delete(t)
      if (@pendingBadConsequence!=nil && !@pendingBadConsequence.isEmpty)
        @pendingBadConsequence.substractVisibleTreasure(t)
      end
      dieIfNoTreasures
    end
  
    def discardHiddenTreasure(t)
      @hiddenTreasures.delete(t)
      if (@pendingBadConsequence!=nil && !@pendingBadConsequence.isEmpty)
        @pendingBadConsequence.substractHiddenTreasure(t)
      end
      dieIfNoTreasures
    end
    
    def buyLevels(visible,hidden)
      levelsMayBought=computeGoldCoinsValue(visible)
      puts "Nievelescon: #{levelsMayBought}\n"
      levelsMayBought= levelsMayBought+computeGoldCoinsValue(hidden)
      levels=(levelsMayBought-(levelsMayBought%1000))/1000 #PUEDE QUE MAS ADELANTE DE PROBLEMAS PORQUE LEVELS ES UN FLOAT Y NO UN INT
      puts "Nievelescon: #{levels}\n"

      canI=canIBuyLevels(levels)
      if (canI)
        incrementLevels(levels)
      end
      @visibleTreasures.delete(visible)
      @hiddenTreasures.delete(hidden)
      dealer=CardDealer.instance
      visible.each do |treasure|
        dealer.giveTreasureBack(treasure)
      end
      hidden.each do |treasure|
        dealer.giveTreasureBack(treasure)
      end
      canI
    end
    
#PREGUNTAR   
    def cuentaTesoroO
        @nivel=0
       hiddenTreasures.each do |t|
            @nivel+1
        end 
        return @nivel
    end
    
    def cuentaTesoroV
        @nivel=0
       visibleTreasures.each do |t|
            @nivel+1
        end 
        return @nivel
    end
    
    def validState
      salida=false
      if(@pendingBadConsequence==nil)
        return true
      elsif(@pendingBadConsequence.isEmpty)
        if (@hiddenTreasures.length<=4)
          salida=true
        else
          salida=false
        end
      end
      return salida
    end 

    
    def initTreasures
      dealer=CardDealer.instance
      dice=Dice.instance
      bringToLife
      treasure=dealer.nextTreasure
      @hiddenTreasures.push(treasure)
      number=dice.nextNumber
      if(number>1)
        treasure=dealer.nextTreasure
        @hiddenTreasures.push(treasure)
      end
      if(number==6)
        treasure=dealer.nextTreasure
        @hiddenTreasures.push(treasure)
      end
    end
  
    def hasVisibleTreasures
      if @visibleTreasures.isEmpty
        return false
      else
        return true
      end
      
    end
    
  end

end