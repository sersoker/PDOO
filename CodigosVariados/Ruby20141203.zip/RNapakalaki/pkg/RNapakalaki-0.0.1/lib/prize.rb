module NapakalakiGame
class Prize
  def initialize (treasures,level)
      @treasures=treasures
      @levels=level
  end
    
  attr_reader:levels
  attr_reader:treasures

  
  def to_s
    "Tesoros: #{@treasures} \n Nivel: #{@levels} \n"
  end
end

end
