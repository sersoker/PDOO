module NapakalakiGame
  class Player
    @pendingBadConsequence
    @hiddenTreasures= Array.new
    @visibleTreasures = Array.new
    
    def initialize(name)
      @name=name
      @level=1
      @dead=true
    end
    
    #preguntar alcance de private
    private 
    
    def bringToLife
      @dead=false      
    end
    
    attr_reader:level
    
    def cuentaNV
       @nivel=0
     #/boolean contenido=visibleTreasure.contains(collar)
      @contenido=false
      if !contenido
        visibleTreasures.each do |t|
            @nivel=@nivel+t.minBonus
        end
      else
        visibleTreasures.each do |t|
            @nivel=@nivel+t.maxBonus
        end
        
      end
    end
    
      return nivel
    end
    
    def getCombatLevel
      return level+self.cuentaNV()
    end
   
    def incrementLevels(i)
      if self.canIBuyLevels(i)
        @level=@level+i
      end
      
    end
    
    def decrementLevels(i)
      if @level-i<=0
        @dead=true
      else
        @level=@level-i
      end
    
    def setPendingBadConsequence(b)
      @pendingBadConsequence=b
      
    end
    
    def dieIfNoTreasures
      if @hiddenTreasures.isEmpty && @visibleTreasures.isEmpty
         @dead=true
      end
    end
    
    def discardNecklaceVisible
      visibleTreasures.each do |t|
                if t.getType==TreasureKind.necklace
                    visibleTreasures.remove(t);
                    CardDealer.getInstance.giveTreasureBack(t)
                end
      end
    end
    
    def die
      @level=1
      dealer=CardDealer.getInstance
      @visibleTreasures.each do |treasure|
        dealer.giveTreasureBack(treasure)
      end
      @visibleTreasures.clear
      @hiddenTreasures.each do |treasure|
        dealer.giveTreasureBack(treasure)
      end
      @hiddenTreasures.clear
      dieIfNoTreasures
    end
    
    def computeGoldCoinsValue(t)
    monedas=0
        t.each do |m|
            monedas+m.getGoldCoins
        end
     return monedas/1000
     end
    
    def canIBuyLevels(i)
      if level+i>=10
        return false
      end
      return true
    end
    
    def applyPrize(currentMonster)
      nLevels=@currentMonster.getLevelsGained
      incrementLevels(nLevels)
      nTreasures=@currentMonster.getTreasuresGained
      if(nTreasures>0)
        dealer=CardDealer.getInstance
        for i in 0..nTreasures
          treasure=dealer.nextTreasure
          @hiddenTreasures.push(treasure)
        end
      end
    end
    
    def applyBadConsequence(bad)
      nLevels=bad.getLevels
      decrementLevels(nLevels)
      pendingBad=bad.adjustToFitTreasure(@visibleTreasures, @hiddenTreasures)
      setPendingBadConsequence(pendingBad)
    end
    
#    def canMakeTreasureVisible(t)
#      if t.getType==oneHand
#                return self.cuentaUnaManoVisible<=1
#      elsif t.getType==bothHand
#                return !self.cuentaUnaManoVisible>=1        
#      else
#            for @visibleTreasures.each do |te|
#                if t.getType==te.getType
#                   return false
#                end
#            end
#      end
#        return true
#      
#    end
#    
#    def cuentaUnaManoVisible
#      dato=0    
#         @visibleTreasures.each do |t|
#             if t.getType==TreasureKing.bothHand
#               return 2
#             elsif t.getType==TreasureKind.oneHand
#               dato=dato+1
#             end
#         end
#      return dato;
#    end
#    
    
    def howManyVisibleTreasures(tKind)
        @cuantos=0;
        visibleTreasures.each do |t|
          if t.type==tKind
                   cuantos+1
        return cuantos
      
           end
        end
    end
    
    #preguntar alcance de nuevo
    public 
    def isDeath
      return @death
    end
    
    def getHiddenTreasures
      
    end
    
    def getVisibleTreasures
      
    end
    
    def combat(m)
      myLevel = getCombatLevel
      monsterLevel = m.combatLevel
      if (myLevel>monsterLevel)
        applyPrize(m)
        if (@level>=10)
          combatResult = [CombatResult::WinAndWinGame]
        else
          combatResult = [CombatResult::Win]
        end
      else
        dice = Dice.getInstance
        escape = dice.nextNumber
        if (escape<5)
          amIDead = m.kills
          if (amIDead)
            die
            combatResult=[CombatResult::LoseAndDie]
          else
            bad=m.badConsequence
            combatResult=[CombatResult::Lose]
            applyBadConsequence(bad)
          end
        else
          combatResult=[CombatResult::LoseAndEscape]
        end
      
        
      end
      discardNecklaceIfVisible
      combatResult
      
    end
    
    def makeTreasureVisible(t)
      canI=canMakeTreasureVisible(t)
      if(canI)
        @visibleTreasures.push(t)
        @hiddenTreasures.remove(t)
      end
    end
    
    def discardVisibleTreasure(t)
      @visibleTreasures.remove(t)
      if (@pendingBadConsequence!=nil && !@pendingBadConsequence.isEmpty)
        @pendingBadConsequence.substractVisibleTreasure(t)
      end
      dieIfNoTreasures
    end
  
    def discardHiddenTreasure(t)
      if (@pendingBadConsequence!=nil && !@pendingBadConsequence.isEmpty)
        @pendingBadConsequence.substractHiddenTreasure(t)
      end
      dieIfNoTreasures
    end
    
    def buyLevels(visible,hidden)
      levelsMayBought=computeGoldCoinsValue(visible)
      levelsMayBought= levelsMayBought+computeGoldCoinsValue(hidden)
      levels=levelsMayBought/1000 #PUEDE QUE MAS ADELANTE DE PROBLEMAS PORQUE LEVELS ES UN FLOAT Y NO UN INT
      canI=canIBuyLevels(levels)
      if (canI)
        incrementLevels(levels)
      end
      @visibleTreasures.removeAll(visible)
      @hiddenTreasures.removeAll(hidden)
      dealer=CardDealer.getInstance
      visible.each do |treasure|
        dealer.giveTreasureBack(treasure)
      end
      hidden.each do |treasure|
        dealer.giveTreasureBack(treasure)
      end
      canI
    end
    
#PREGUNTAR   
    def cuentaTesoroO
        @nivel=0
       hiddenTreasures.each do |t|
            @nivel+1
        end 
        return @nivel
    end
    
    def cuentaTesoroV
        @nivel=0
       visibleTreasures.each do |t|
            @nivel+1
        end 
        return @nivel
    end
    
    
    def validState
      if @pendingBadConsequence.isEmpty&&self.cuentaTesoroO<=4
        return true
      else
        return false
      end
    end
    
    def initTreasures
      dealer=CardDealer.getInstance
      dice=Dice.getInstance
      bringToLife
      treasure=dealer.nextTreasure
      @hiddenTreasures.push(treasure)
      number=dice.nextNumber
      if(number>1)
        treasure=dealer.nextTreasure
        @hiddenTreasures.push(treasure)
      end
      if(number==6)
        treasure=dealer.nextTreasure
        @hiddenTreasures.push(treasure)
      end
    end
  
    def hasVisibleTreasures
      if @visibleTreasures.isEmpty
        return false
      else
        return true
      end
      
    end
    
    def getLevels
      
    end
  
  end
end
