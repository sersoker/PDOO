module NapakalakiGame
  class Treasure
   
    def initialize(name,goldCoins,minBonus,maxBonus,type)
     @name=name
     @goldCoins=goldCoins
     @minBonus=minBonus
     @maxBonus=maxBonus
     @type=type
    end
    
    attr_reader:name
    attr_reader:goldCoins
    attr_reader:minBonus
    attr_reader:maxBonus
    attr_reader:type
    
  end
end