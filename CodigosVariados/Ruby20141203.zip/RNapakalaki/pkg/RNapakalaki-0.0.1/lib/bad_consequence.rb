module NapakalakiGame
class BadConsequence
  def initialize(aText=nil, someLevels=0, someVisibleTreasures=0, 
    someHiddenTreasures=0, someSpecificVisibleTreasures=Array.new(), 
    someSpecificHiddenTreasures=Array.new(), death=false) 
  
    @text=aText
    @levels=someLevels
    @nVisibleTreasures=someVisibleTreasures
    @nHiddenTreasures=someHiddenTreasures
    @specificVisibleTreasures=someSpecificVisibleTreasures
    @specificHiddenTreasures=someSpecificHiddenTreasures
    @death=death
    
  end
  
  def self.newLevelNumberOfTreasures (aText, someLevels, 
    someVisibleTreasures, someHiddenTreasures)
    new(aText,someLevels,someVisibleTreasures,someHiddenTreasures)
  end
  
  def self.newLevelSpecificTreasures (aText, someLevels,        
    someSpecificVisibleTreasures, someSpecificHiddenTreasures)
    new(aText,someLevels,0,0,someSpecificVisibleTreasures,someSpecificHiddenTreasures)
  end
  
  def self.newDeath (aText)
    new(aText,0,0,0,Array.new(),Array.new(),true)
  end
  
private_class_method :new

attr_reader:levels
attr_reader:text
attr_reader:nVisibleTreasures
attr_reader:nHiddenTreasures
attr_reader:specificVisibleTreasures
attr_reader:specificHiddenTreasures

  def to_s
  "Descripcion: #{@text} \n Niveles perdidos: #{@levels} \n
  Tesoros visibles perdidos: #{@nVisibleTreasures} \n  
  Tesoros ocultos perdidos: #{@nHiddenTreasures}\n
  Muerte: #{@death}"
  end
  
  public 
  
  def isEmpty
    return true;
  end
  
  def substractVisibleTreasure(t)
    encontrado = false
    for i in 0..@specificVisibleTreasures.size-1 && !encontrado
      if t.type == @specificVisibleTreasures[i]
        encontrado = true
        @specificVisibleTreasures.delete(i)
      end
    end
    if !encontrado
      @nVisibleTreasures = @nVisibleTreasures - 1
    end
  end
  
  def substractHiddenTreasure(t)
    encontrado = false
    for i in 0..@specificHiddenTreasures.size-1 && !encontrado
      if t.type == @specificHiddenTreasures[i]
        encontrado = true
        @specificHiddenTreasures.delete(i)
      end
    end
    if !encontrado
      @nHiddenTreasures = @nHiddenTreasures - 1 
    end    
  end
  
  def adjustToFitTreasure(v,h)
    for i in 0..@specificVisibleTreasures.size
      encontrado=false
      for i in 0..v.size && !encontrado
        if (@specificVisibleTreasures.at(i) == v.at(i))
          encontrado=true
        end
      end
      if(!encontrado)
        @specificVisibleTreasures.remove(@specificVisibleTreasures.at(i))
        i=i-1
      end
    end
    
    for i in 0..@specificHiddenTreasures.size
      encontrado=false
      for i in 0..v.size && !encontrado
        if (@specificHiddenTreasures.at(i) == v.at(i))
          encontrado=true
        end
      end
      if(!encontrado)
        @specificHiddenTreasures.remove(@specificHiddenTreasures.at(i))
        i=i-1
      end
    end    
    
    if (@nVisibleTreasures > v.size)
      @nVisibleTreasures = v.size
    end
    
    if (@nHiddenTreasures > v.size)
      @nHiddenTreasures = v.size
    end    
    
  end
  
  def myBadConsequenceIsDeath
    return @death;
  end
  
end


end
