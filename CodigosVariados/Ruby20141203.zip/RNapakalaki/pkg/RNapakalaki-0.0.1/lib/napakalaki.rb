require "singleton"
module NapakalakiGame
  class Napakalaki
    include Singleton

    @currentMonster;
    @dealer;
    @currentPlayer;
    @players=Array.new();

    private 

    def initPlayers(names)
      names.each do |p|
        @players.push(p)
    end

    end

    def nextPlayer
      noplayer=true
     if @currentPlayer!=nil
       Players.each do |p|
         if p==@currentPlayer && noplayer
             noplayer=false
         elsif !noplayer
           return p
         end
      end
     end
     @rand=rand(@Players.size)
     return @Players.at(@rand)
    end

    def nextTurnAllowed
      return @currenPlayer.validState()
    end

    public 


    def developCombat
      combatResult = @currentPlayer.combat(@currentMonster)
      @dealer.giveMonsterBack(@currentMonster)
      combatResult
    end

    def discardVisibleTreasures(treasures)
       treasures.each do |treasure|
         @currentPlayer.discardVisibleTreasure(treasure)
         @dealer.giveTreasureBack(treasure)
       end
    end  
    
    def discardHiddenTreasures(treasures)
       treasures.each do |treasure|
         @currentPlayer.discardHiddenTreasure(treasure)
         @dealer.giveTreasureBack(treasure)
       end
    end

    def makeTreasuresVisible(treasures)
      treasures.each do |t|
          @currentPlayer.makeTreasureVisible(t)
      end
    end
    
    def buyLevels(visible,hidden)
      canI=@currentPlayer.buyLevels(visible, hidden)
      canI
    end
    
    def initGame(players)
      initPlayers(players)
      @dealer.initCards
      nextTurn
    end
  
    def getCurrentPlayer()
      return @currentPlayer      
    end
  
    def getCurrentMonster()
      return @currentMonster
    end
    
    def nextTurn
      stateOK = nextTurnAllowed
      if ( stateOK )
        @currentMonster = @dealer.nextMonster
        @currentPlayer = nextPlayer
        dead = @currentPlayer.isDead
        if(dead)
          @currentPlayer.initTreasures
        end
      end
      stateOK
    end
    
    def endOfGame(result)
      return if result==CombatResult.WinAndWinGame      
    end
    
  end
end
