
class Dice
  include Singleton
  
  Dice.instance
  
end
