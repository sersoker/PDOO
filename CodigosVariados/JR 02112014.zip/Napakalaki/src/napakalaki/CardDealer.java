/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package napakalaki;

/**
 *
 * @author sersoker
 */
public class CardDealer {
    private static final CardDealer INSTANCE = null;
    
    private CardDealer() {
    }
    
    public static CardDealer getInstance() {
        return CardDealerHolder.INSTANCE;
    }
    
    private static class CardDealerHolder {

        private static final CardDealer INSTANCE = new CardDealer();
    }
    
    private void initTreasuresCardDeck(){
    
    }
    
    private void initMonsterCardDeck(){
    
    }
    
    private void shuffleTreasures(){
    
    }
    
    private void shuffleMonsters(){
    
    }
    
    public Treasure nextTreasure(){
            return null; 
    }
    
    public Monster nextMonster(){
        return null; 
    }
    
    public void giveTreasureBack(Treasure t){
    
    }
    
    public void giveMonsterBack(Monster m){
    
    }
    
    public void initCards(){
    
    }
    
}
