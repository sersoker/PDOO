/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package napakalaki;

import java.util.ArrayList;

/**
 *
 * @author Aarón
 */
public class Napakalaki {
    
    private static final Napakalaki instance = null;
    
    private Napakalaki() {
    }
    
    private void initPlayers(ArrayList<String> names){
    
    }
    
    private Player nextPlayer(){
            return null; 
    }
  
    private boolean nextTurnAllowed(){
        return false;
    }
    
    public Napakalaki getInstance (){
        return instance;
    }
    
    public CombatResult developCombat (){
        return CombatResult.Win;
    }
    
    public void discardVisibleTreasures (ArrayList<Treasure> treasures){
        
    }

    
   
    public void discardHiddenTreasures (ArrayList<Treasure> treasures){
        
    }

    public void makeTreasuresVisible(ArrayList<Treasure> treasures){
        
    }
    
    public boolean buyLevels(ArrayList<Treasure> visible, ArrayList<Treasure> hidden){
        return true;
    }
   

    public void initGame( ArrayList<String> players ){
        
    }

    public Player getCurrentPlayer(){
            return null; 
    }
  
    public Monster getCurrentMonster(){
        return null; 
    }
    
    public boolean nextTurn(){
        return false;
    }
    
    public boolean endOfGame( CombatResult result ){
        return false;
    }
    
}
