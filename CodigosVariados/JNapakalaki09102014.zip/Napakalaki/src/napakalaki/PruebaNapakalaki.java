/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package napakalaki;



/**
 *
 * @author sersoker
 */
public class PruebaNapakalaki {
   
    public Prize price = new Prize(2,2);
   int pepe = price.getLevel();
   print pepe;
    
    
    //public BadConsequence bc= new BadConsequence();
    //public Monster Monstruo(pepe,2,price,bc);
   
}
