# To change this license header, choose License Headers in Project Properties.
# To change this template file, choose Tools | Templates
# and open the template in the editor.

class Prize
  def initialize (treasures=nil,level=nil)
      @tesoro=treasures
      @nivel=level
  end
    
  att_reader nivel,tesoro
  
  def to_s
    "Tesoros: #{@tesoro} \n Nivel: #{@nivel} \n"
  end
end
