monsters=Array.new

price=new.Prize(2,1)
badc=BadConsequence.newLevelSpecificTreasures("Pierdes tu armadura visible y otra oculta",)

(aText, someLevels,        
    someSpecificVisibleTreasures, someSpecificHiddenTreasures)
    new(aText,someLevels,0,0,someSpecificVisibleTreasures,someSpecificHiddenTreasures)
  end