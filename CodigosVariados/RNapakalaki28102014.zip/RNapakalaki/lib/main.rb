#encoding: utf­8
require './prize.rb'
require './bad_consequence.rb'
require './treasure_kind.rb'
require './monster.rb'
monsters=Array.new

price=Prize.new(2,1)
badc=BadConsequence.newLevelSpecificTreasures("Pierdes tu armadura visible y otra oculta",0,TreasureKind::ARMOR,TreasureKind::ARMOR)
monstruo=Monster.new("3 Byakhees de bonanza",8,price,badc)
monsters.push(monstruo)

price=Prize.new(1,1)
badc=BadConsequence.newLevelSpecificTreasures("Embobados con el lindo primigenio te descartas de tu casco visible",0,TreasureKind::HELMET)
monstruo=Monster.new("Chibithulhu",2,price,badc)
monsters.push(monstruo)

price=Prize.new(1,1)
badc=BadConsequence.newLevelSpecificTreasures("El primordial bostezo contagioso. Pierdes el calzado visible",0,TreasureKind::SHOE)
monstruo=Monster.new("El sopor de Dunwich",2,price,badc)
monsters.push(monstruo)

price=Prize.new(4,1)
badc=BadConsequence.newLevelSpecificTreasures("Te atrapan para llevarte de fiesta y te dejan caer en mitad del vuelo. Descarta 1 mano visible y 1 mano oculta",0,TreasureKind::HAND,TreasureKind::HAND)
monstruo=Monster.new("Angeles de la noche ibicenca",14,price,badc)
monsters.push(monstruo)

price=Prize.new(3,1)
badc=BadConsequence.newLevelNumberOfTreasures("Pierdes todos tus tesoros visibles",0,6,0)
monstruo=Monster.new("El gorron en elumbral",10,price,badc)
monsters.push(monstruo)

price=Prize.new(2,1)
badc=BadConsequence.newLevelSpecificTreasures("Pierdes la armadura visible",0,TreasureKind::ARMOR)
monstruo=Monster.new("H.P.Munchcraft",6,price,badc)
monsters.push(monstruo)

price=Prize.new(1,1)
badc=BadConsequence.newLevelSpecificTreasures("Sientes bichos bajo la ropa. Descarta la armadura visible",0,TreasureKind::ARMOR)
monstruo=Monster.new("Bichgooth",2,price,badc)
monsters.push(monstruo)

price=Prize.new(4,2)
badc=BadConsequence.newLevelNumberOfTreasures("Pierdes 5 niveles y 3 tesoros visibles.",5,3,0)
monstruo=Monster.new("El rey de rosa",13,price,badc)
monsters.push(monstruo)

price=Prize.new(1,1)
badc=BadConsequence.newLevelNumberOfTreasures("Toses los pulmones ypierdes 2 niveles.",2,0,0)
monstruo=Monster.new("La que redacta en las tinieblas",2,price,badc)
monsters.push(monstruo)

price=Prize.new(2,1)
badc=BadConsequence.newDeath("Estos monstruos resultan bastante superciales y te aburren mortalmente. Estas muerto")
monstruo=Monster.new("Los hondos",8,price,badc)
monsters.push(monstruo)

price=Prize.new(2,1)
badc=BadConsequence.newLevelNumberOfTreasures("Pierdes 2 niveles y 2 tesoros oculto",2,0,2)
monstruo=Monster.new("Semillas Cthulhu",4,price,badc)
monsters.push(monstruo)

price=Prize.new(2,1)
badc=BadConsequence.newLevelSpecificTreasures("Te intentas escaquear.Pierdes una mano visible.",0,TreasureKind::HAND)
monstruo=Monster.new("Dameargo",1,price,badc)
monsters.push(monstruo)

price=Prize.new(1,1)
badc=BadConsequence.newLevelNumberOfTreasures("Da mucho asquito. Pierdes 3 niveles.",3,0,0)
monstruo=Monster.new("Pollipolipo volante",3,price,badc)
monsters.push(monstruo)

price=Prize.new(3,1)
badc=BadConsequence.newDeath("No le hace gracia que pronuncien mal su nombre. Estas muerto")
monstruo=Monster.new("Yskhtihyssg-Goth",12,price,badc)
monsters.push(monstruo)


price=Prize.new(4,1)
badc=BadConsequence.newDeath("La familia te atrapa. Estas muerto.")
monstruo=Monster.new("La familia feliz",1,price,badc)
monsters.push(monstruo)

price=Prize.new(2,1)
badc=BadConsequence.newLevelSpecificTreasures("La quinta directiva primaria te obliga a perder 2 niveles y un tesoro 2 manos visible",2,TreasureKind::BOTHHAND)
monstruo=Monster.new("Roboggoth",8,price,badc)
monsters.push(monstruo)

price=Prize.new(1,1)
badc=BadConsequence.newLevelSpecificTreasures("Te asusta en la noche. Pierdes un casco visible",0,TreasureKind::HELMET)
monstruo=Monster.new("El espia",5,price,badc)
monsters.push(monstruo)

price=Prize.new(1,1)
badc=BadConsequence.newLevelNumberOfTreasures("Menudo susto te llevas. Pierdes 2 niveles y 5 tesoros visibles.",2,5,0)
monstruo=Monster.new("El lenguas",20,price,badc)
monsters.push(monstruo)

price=Prize.new(1,1)
badc=BadConsequence.newLevelNumberOfTreasures("Te faltan manos para tanta cabeza. Pierdes 3 niveles y tus tesoros visibles de las manos.",3,6,0)
monstruo=Monster.new("efalo",20,price,badc)
monsters.push(monstruo)


for i in 0..monsters.length
  if monsters.combatLevel>10
    put monsters.to_s
  end
end