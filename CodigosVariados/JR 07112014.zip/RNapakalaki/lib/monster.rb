module NapakalakiGame
  class Monster

    def initialize(nombre=nil,nivelCombate=nil,prize=nil,bc=nil)
      @name=nombre
      @combatLevel=nivelCombate
      @prize=prize
      @badConsequence=bc
    end

    attr_reader:name
    attr_reader:combatLevel

    def to_s
      "Nombre: #{@name} \n Nivel de Combate: #{@combatLevel}\n"
    end

    def consecuencia
      @bc.levels
    end

    def gananivel
      @prize.level 
    end

    def getBadConsequence
       @badConsequence
    end
    
    def getLevelsGained
      return @prize.level
    end
    
    def getTreasuresGained
      return @prize.treasures
      
    end
    
    def kills
      return @badConsequence.myBadConsequenceIsDeath
      
    end
    
    
  end
end