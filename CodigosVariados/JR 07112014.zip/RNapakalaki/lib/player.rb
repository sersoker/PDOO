module NapakalakiGame
  class Player
    @pendingBadConsequence;
    @dice;
    @cardDealer;
    @combatResult;
    @hiddenTreasures= Array.new
    @visibleTreasures = Array.new
    
    def initialize(name)
      @name=name
      @level=1
      @dead=true
    end
    
    #preguntar alcance de private
    private 
    
    def bringToLife
      @dead=false      
    end
    
    attr_reader:level
    
    def cuentaNV
       @nivel=0;
     #/boolean contenido=visibleTreasure.contains(collar)
      @contenido=false;
      if !contenido
        visibleTreasures.each do |t|
            @nivel=@nivel+t.minBonus
        end
      else
        visibleTreasures.each do |t|
            @nivel=@nivel+t.maxBonus
        end
        
      end
    end
    
      return nivel;
    end
    
    def getCombatLevel
      return level+self.cuentaNV();
    end
   
    def incrementLevel(i)
      if self.canIBuyLevels(i)
        @level=@level+i
      end
      
    end
    
    def decrementLevel(i)
      if @level-i<=0
        @dead=true
      else
        @level=@level-i
      end
    
    def setPendingBadConsequence(b)
      @pendingBadConsequence=b
      
    end
    
    def dieIfNoTreasures
      if @hiddenTreasures.isEmpty && @visibleTreasures.isEmpty
         @dead=true
      end
    end
    
    def discardNecklaceVisible
      
    end
    
    def die
      
    end
    
    def computeGoldCoinsValue(t)
      
    end
    
    def canIBuyLevels(i)
      if level+i>=10
        return false
      end
      return true
    end
    
    def applyPrize(currentMonster)
      
    end
    
    def applyBadConsequence(bad)
      
    end
    
    def canMakeTreasureVisible(t)
      
    end
    
    def howManyVisibleTreasures(tKind)
        @cuantos=0;
        visibleTreasures.each do |t|
          if t.type==tKind
                   cuantos+1
        return cuantos
      
           end
        end
    end
    
    #preguntar alcance de nuevo
    public 
    def isDeath
      return @death
    end
    
    def getHiddenTreasures
      
    end
    
    def getVisibleTreasures
      
    end
    
    def combat(m)
      
    end
    
    def makeTreasureVisible(t)
      
    end
    
    def discardVisibleTreasure(t)
      
    end
  
    def discardHiddenTreasure(t)
      
    end
    
    def buyLevels(visible,hidden)
            
    end
    
#PREGUNTAR   
    def cuentaTesoroO
        @nivel=0
       hiddenTreasures.each do |t|
            @nivel+1
        end 
        return @nivel
    end
    
    def cuentaTesoroV
        @nivel=0
       visibleTreasures.each do |t|
            @nivel+1
        end 
        return @nivel
    end
    
    
    def validState
      if @pendingBadConsequence.isEmpty&&self.cuentaTesoroO<=4
        return true
      else
        return false
      end
    end
    
    def initTreasures
      
    end
  
    def hasVisibleTreasures
      if @visibleTreasures.isEmpty
        return false
      else
        return true
      end
      
    end
    
    def getLevels
      
    end
  
  end
end
