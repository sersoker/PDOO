module NapakalakiGame
class BadConsequence
  def initialize(aText=nil, someLevels=0, someVisibleTreasures=0, 
    someHiddenTreasures=0, someSpecificVisibleTreasures=Array.new(), 
    someSpecificHiddenTreasures=Array.new(), death=false) 
  
    @text=aText
    @levels=someLevels
    @nVisibleTreasures=someVisibleTreasures
    @nHiddenTreasures=someHiddenTreasures
    @specificVisibleTreasures=someSpecificVisibleTreasures
    @specificHiddenTreasures=someSpecificHiddenTreasures
    @death=death
    
  end
  
  def self.newLevelNumberOfTreasures (aText, someLevels, 
    someVisibleTreasures, someHiddenTreasures)
    new(aText,someLevels,someVisibleTreasures,someHiddenTreasures)
  end
  
  def self.newLevelSpecificTreasures (aText, someLevels,        
    someSpecificVisibleTreasures, someSpecificHiddenTreasures)
    new(aText,someLevels,0,0,someSpecificVisibleTreasures,someSpecificHiddenTreasures)
  end
  
  def self.newDeath (aText)
    new(aText,0,0,0,Array.new(),Array.new(),true)
  end
  
private_class_method :new

attr_reader:levels
attr_reader:text
attr_reader:nVisibleTreasures
attr_reader:nHiddenTreasures
attr_reader:specificVisibleTreasures
attr_reader:specificHiddenTreasures

  def to_s
  "Descripcion: #{@text} \n Niveles perdidos: #{@levels} \n
  Tesoros visibles perdidos: #{@nVisibleTreasures} \n  
  Tesoros ocultos perdidos: #{@nHiddenTreasures}\n
  Muerte: #{@death}"
  end
  
  public 
  
  def isEmpty
    return true;
  end
  
  def substractVisibleTreasure(t)
    
  end
  
  def substractHiddenTreasure(t)
    
  end
  
  def adjustToFitTreasure(v,h)
    
  end
  
  def myBadConsequenceIsDeath
    return @death;
  end
  
end


end
