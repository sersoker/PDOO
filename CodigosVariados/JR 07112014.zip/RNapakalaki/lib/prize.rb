module NapakalakiGame
class Prize
  def initialize (treasures,level)
      @treasures=treasures
      @level=level
  end
    
  attr_reader:level
  attr_reader:treasures

  
  def to_s
    "Tesoros: #{@treasures} \n Nivel: #{@level} \n"
  end
end

end
