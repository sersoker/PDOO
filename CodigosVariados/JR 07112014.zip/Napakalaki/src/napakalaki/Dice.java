package napakalaki;

import java.util.Random;
public class Dice {
    
    private static final Dice instance = null;
    
    private Dice() {
    }
    
    public static Dice getInstance() {
        return instance;
    }
    
    public static int nextNumber(){
        Random diceRoller = new Random();
        int roll = diceRoller.nextInt(6) + 1;
        return roll;
    }
    
}
