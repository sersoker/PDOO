package napakalaki;

import java.util.ArrayList;

public class Player {
    private boolean dead;
    private String name;
    private int level;
    private BadConsequence pendingBadConsequence;
    private Dice dice;
    private CardDealer cardDealer;
    private CombatResult combatResult;
    private ArrayList <Treasure> hiddenTreasure=new ArrayList();
    private ArrayList <Treasure> visibleTreasure=new ArrayList();
    

    public Player(String name) {
        this.name = name;
        this.level= 1;
        this.dead = true;
    }
    
    private void bringToLife(){
        dead=false;
    }
    
    private int cuentaNV(){
      int nivel=0;
      //boolean contenido=visibleTreasure.contains(collar)
      boolean contenido=false;
      if (!contenido){
        for(Treasure t: visibleTreasure){
        nivel= nivel+ t.getMinBonus();
        }
      }
      else{
        for(Treasure t: visibleTreasure){
        nivel= nivel+ t.getMaxBonus();
        }
      }
    
      return nivel;
    }
  
    
    private int getCombatLevel(){
        return level+this.cuentaNV();
    }
    
    private void incrementLevel(int i){
        if (this.canIBuyLevels(i))
            level=level+i;
    
    }
   
    private void decrementLevel(int i){
        if (level-i<=0){
            this.die();
            level=0;
        }            
        else
        {
            level=level-1;
        }
    
    }
    
    private void setPendingBadConsequence(BadConsequence b){
        this.pendingBadConsequence=b;
    
    }
    
    private void dieIfNoTreasures(){
        // Consultar
        if (visibleTreasure.isEmpty()&&hiddenTreasure.isEmpty())
            dead=true;    
    }
    
    private void discardNecklacelfVisible(){
    
    }
    
    private void die (){
        dead=true;
    
    }

    private int computeGoldCoinsValue(Treasure t){
        return 1;
    }

    private boolean canIBuyLevels(int i){
        if (level+i>=10)
        return false;
        else
        return true;
    
    }

    private void applyPrize(Monster currentMonster){
    
    
    }
    
    private void applyBadConsequence(BadConsequence b){
    
    }

    private boolean canMakeTreasureVisible(Treasure t){
        return true;
    }

    private int howManyVisibleTreasures(TreasureKind tKind){
        int cuantos=0;
           for(Treasure t: visibleTreasure){
               if (t.getType()==tKind)
                   cuantos++;
           }
        
        return cuantos;
    }
    
    public boolean isDead(){
        return dead;
    }
    
    public ArrayList<Treasure> getHiddenTreasures(){
        return new ArrayList();
    
    }
    
    public ArrayList<Treasure> getVisibleTreasures(){
        return new ArrayList();
    
    }
    
   public CombatResult combat (Monster m){
               return null; 
    }    

    public void makeTreasureVisible(Treasure t){
    
    }
    
    public void discardVisibleTreasure(Treasure t){
    
    }
    
    public void discarHiddenTreasure(Treasure t){
    
    }
    
    public boolean buyLevels(ArrayList<Treasure> visible, ArrayList<Treasure> hidden ){
        return true;
    }
    
    private int cuentaTesoroO(){
        int nivel=0;
        for(Treasure t: hiddenTreasure){
            nivel++;
        }
        return nivel;
    
    }
       private int cuentaTesoroV(){
        int nivel=0;
        for(Treasure t: visibleTreasure){
            nivel++;
        }
        return nivel;
    
    }
    
    
    public boolean validState(){
        if (pendingBadConsequence.isEmpty() == true&&this.cuentaTesoroO()<=4)
            return true;
        else
            return false;
    }
    
    public void initTreasures(){
    
    }
    
    public boolean hasVisibleTreasures(){
        if (this.cuentaTesoroV()>0)
            return true;
        else
            return false;
    }
    
    public int getlevels(){
        return level;
    }
    
}













