package GUI;
import NapakalakiGame.Napakalaki;

public class NapakalakiView extends javax.swing.JFrame {
    
    private Napakalaki napakalakiModel;
    private boolean combatido = false;
    
    public void setNapakalaki(Napakalaki nap){
       napakalakiModel=nap;
       VistaJugador.setPlayer(napakalakiModel.getCurrentPlayer());
       VistaJugador.setNapakalaki(napakalakiModel);
       Combat.setEnabled(false);
           this.habilitaTurno();
       repaint();
       revalidate();
    }
    
    public void habilitaTurno(){
        if(!combatido)
             NextTurn.setEnabled(false);
        else{
            NextTurn.setEnabled(true);
            combatido=false;
        }
    }
    
    /** Creates new form NapakalakiView */
    public NapakalakiView() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        VistaJugador = new GUI.PlayerView();
        resultado = new javax.swing.JLabel();
        Informacion = new javax.swing.JLabel();
        MeetMonster = new javax.swing.JButton();
        Combat = new javax.swing.JButton();
        NextTurn = new javax.swing.JButton();
        VistaMonstruo = new GUI.MonsterView();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        VistaJugador.setBorder(javax.swing.BorderFactory.createTitledBorder("Jugador"));

        resultado.setText("    ");
        resultado.setBorder(javax.swing.BorderFactory.createTitledBorder("Resultado del Combate"));

        Informacion.setText("    ");
        Informacion.setBorder(javax.swing.BorderFactory.createTitledBorder("Otra Informacion"));

        MeetMonster.setText("Meet The Monster");
        MeetMonster.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MeetMonsterActionPerformed(evt);
            }
        });

        Combat.setText("Combat");
        Combat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CombatActionPerformed(evt);
            }
        });

        NextTurn.setText("Next Turn");
        NextTurn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NextTurnActionPerformed(evt);
            }
        });

        VistaMonstruo.setBorder(javax.swing.BorderFactory.createTitledBorder("Monstruo"));

        org.jdesktop.layout.GroupLayout layout = new org.jdesktop.layout.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(layout.createSequentialGroup()
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(layout.createSequentialGroup()
                        .add(6, 6, 6)
                        .add(VistaMonstruo, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                        .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING, false)
                            .add(MeetMonster)
                            .add(Combat)
                            .add(NextTurn)
                            .add(Informacion, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 343, Short.MAX_VALUE)
                            .add(resultado, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED, 39, Short.MAX_VALUE))
                    .add(VistaJugador, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(layout.createSequentialGroup()
                .add(VistaJugador, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 322, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING, false)
                    .add(org.jdesktop.layout.GroupLayout.TRAILING, layout.createSequentialGroup()
                        .add(resultado)
                        .add(18, 18, 18)
                        .add(Informacion)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .add(MeetMonster)
                        .add(18, 18, 18)
                        .add(Combat)
                        .add(18, 18, 18)
                        .add(NextTurn)
                        .add(124, 124, 124))
                    .add(layout.createSequentialGroup()
                        .add(VistaMonstruo, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap())))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void MeetMonsterActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MeetMonsterActionPerformed
       VistaMonstruo.setMonster(napakalakiModel.getCurrentMonster());
       MeetMonster.setEnabled(false);
       Combat.setEnabled(true);
       VistaJugador.ponerVisible(false);
       repaint();
       revalidate();
    }//GEN-LAST:event_MeetMonsterActionPerformed

    private void CombatActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CombatActionPerformed
        resultado.setText(napakalakiModel.developCombat().toString());
        Combat.setEnabled(false);
        VistaJugador.setPlayer(napakalakiModel.getCurrentPlayer());
        VistaJugador.ponerVisible(true);
        combatido=true;
        this.habilitaTurno();

    }//GEN-LAST:event_CombatActionPerformed

    private void NextTurnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NextTurnActionPerformed
     if(!napakalakiModel.nextTurn())
         Informacion.setText("No se puede pasar de turno");
     else{
        VistaJugador.setPlayer (napakalakiModel.getCurrentPlayer());
        MeetMonster.setEnabled(true);
        NextTurn.setEnabled(false);
     combatido=false;
     }

    }//GEN-LAST:event_NextTurnActionPerformed

    public void showView(){
        this.setVisible(true);
    }
    
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Combat;
    private javax.swing.JLabel Informacion;
    private javax.swing.JButton MeetMonster;
    private javax.swing.JButton NextTurn;
    private GUI.PlayerView VistaJugador;
    private GUI.MonsterView VistaMonstruo;
    private javax.swing.JLabel resultado;
    // End of variables declaration//GEN-END:variables
}
