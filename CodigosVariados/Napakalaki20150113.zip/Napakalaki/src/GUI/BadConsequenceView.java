package GUI;

import NapakalakiGame.Monster;
import NapakalakiGame.Treasure;
import NapakalakiGame.TreasureKind;
import java.util.ArrayList;

public class BadConsequenceView extends javax.swing.JPanel {
    Monster monsterModel;
    
    public BadConsequenceView() {
        initComponents();
    }
    public void setBadConsequence (Monster m) {
        monsterModel = m;
        
        Niveles.setText(Integer.toString(monsterModel.getBadConsequence().getLevels()));
        Texto.setText(monsterModel.getBadConsequence().getText());
        death.setText(Boolean.toString(monsterModel.getBadConsequence().myBadConsequenceIsDeath()));
        nOcultos.setText(Integer.toString(monsterModel.getBadConsequence().nHiddenTreasures()));
        nVisibles.setText(Integer.toString(monsterModel.getBadConsequence().nVisibleTreasures()));

        fillTreasurePanel (TOculEsp,monsterModel.getBadConsequence().getSpecificHiddenTreasures());
        fillTreasurePanel (TVisibleEsp, monsterModel.getBadConsequence().getSpecificVisibleTreasures());
       
        repaint();
        revalidate();
    }
    
    public void fillTreasurePanel (javax.swing.JPanel aPanel, ArrayList<TreasureKind> aList) {
        // Se elimina la información antigua
        aPanel.removeAll();
        // Se recorre la lista de tipos de tesoro construyendo y añadiendo sus vistas al panel
        for (TreasureKind t : aList) {
        TreasureKindView aTreasureKindView = new TreasureKindView();
        aTreasureKindView.setTreasureKind (t);
        aTreasureKindView.setVisible (true);
        aPanel.add (aTreasureKindView);
        }
        // Se fuerza la actualización visual del panel
        aPanel.repaint();
        aPanel.revalidate();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Texto = new javax.swing.JLabel();
        Niveles = new javax.swing.JLabel();
        nVisibles = new javax.swing.JLabel();
        nOcultos = new javax.swing.JLabel();
        death = new javax.swing.JLabel();
        TVisibleEsp = new javax.swing.JPanel();
        TOculEsp = new javax.swing.JPanel();

        Texto.setText("    ");
        Texto.setBorder(javax.swing.BorderFactory.createTitledBorder("Texto"));

        Niveles.setText("    ");
        Niveles.setBorder(javax.swing.BorderFactory.createTitledBorder("Niveles"));

        nVisibles.setText("  ");
        nVisibles.setBorder(javax.swing.BorderFactory.createTitledBorder("Nº Visibles"));

        nOcultos.setText("   ");
        nOcultos.setBorder(javax.swing.BorderFactory.createTitledBorder("Nº Ocultos"));

        death.setText("   ");
        death.setBorder(javax.swing.BorderFactory.createTitledBorder("MUERTO"));

        TVisibleEsp.setBorder(javax.swing.BorderFactory.createTitledBorder("TesorosVisiblesEspecificos"));

        javax.swing.GroupLayout TVisibleEspLayout = new javax.swing.GroupLayout(TVisibleEsp);
        TVisibleEsp.setLayout(TVisibleEspLayout);
        TVisibleEspLayout.setHorizontalGroup(
            TVisibleEspLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        TVisibleEspLayout.setVerticalGroup(
            TVisibleEspLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 34, Short.MAX_VALUE)
        );

        TOculEsp.setBorder(javax.swing.BorderFactory.createTitledBorder("TesorosOcultosEspecificos"));

        javax.swing.GroupLayout TOculEspLayout = new javax.swing.GroupLayout(TOculEsp);
        TOculEsp.setLayout(TOculEspLayout);
        TOculEspLayout.setHorizontalGroup(
            TOculEspLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        TOculEspLayout.setVerticalGroup(
            TOculEspLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 36, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(TVisibleEsp, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(TOculEsp, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(Texto, javax.swing.GroupLayout.PREFERRED_SIZE, 288, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(death, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(Niveles, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 25, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(nVisibles, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(nOcultos, javax.swing.GroupLayout.DEFAULT_SIZE, 80, Short.MAX_VALUE))
                        .addGap(0, 12, Short.MAX_VALUE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(Niveles, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(nVisibles, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(death, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(nOcultos, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(Texto, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(TVisibleEsp, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(TOculEsp, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
    }// </editor-fold>//GEN-END:initComponents


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Niveles;
    private javax.swing.JPanel TOculEsp;
    private javax.swing.JPanel TVisibleEsp;
    private javax.swing.JLabel Texto;
    private javax.swing.JLabel death;
    private javax.swing.JLabel nOcultos;
    private javax.swing.JLabel nVisibles;
    // End of variables declaration//GEN-END:variables
}
