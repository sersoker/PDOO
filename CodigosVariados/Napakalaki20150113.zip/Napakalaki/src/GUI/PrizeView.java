package GUI;

import NapakalakiGame.Monster;

public class PrizeView extends javax.swing.JPanel {
Monster viewModel;
        
    public PrizeView() {
        initComponents();
    }
    
    public void setPrize (Monster m) {
        viewModel=m;
        Niveles.setText(Integer.toString(viewModel.getLevelsGained()));
        Tesoros.setText(Integer.toString(viewModel.getTreasuresGained()));
        repaint();
        revalidate();
      
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Tesoros = new javax.swing.JLabel();
        Niveles = new javax.swing.JLabel();

        Tesoros.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        Tesoros.setText("    ");
        Tesoros.setBorder(javax.swing.BorderFactory.createTitledBorder("Tesoros"));

        Niveles.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        Niveles.setText("    ");
        Niveles.setBorder(javax.swing.BorderFactory.createTitledBorder("Niveles"));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(Tesoros, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(Niveles, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Tesoros, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Niveles, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 0, 0))
        );
    }// </editor-fold>//GEN-END:initComponents


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Niveles;
    private javax.swing.JLabel Tesoros;
    // End of variables declaration//GEN-END:variables
}
