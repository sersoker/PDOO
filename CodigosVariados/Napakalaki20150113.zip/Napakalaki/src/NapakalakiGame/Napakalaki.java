package NapakalakiGame;

import java.util.ArrayList;
import java.util.Random;

public class Napakalaki {
    
    private static final Napakalaki instance= new Napakalaki();
    private Player currentPlayer=null;
    private ArrayList <Player> Players = new ArrayList();
    private CardDealer dealer=CardDealer.getInstance();
    private Monster currentMonster;
    
    private Napakalaki() {
       
    }
    
    private void initPlayers(ArrayList<String> names){
         for(String s: names){
            Player pla=new Player(s);
            this.Players.add(pla);            
         }
    }
    
    private Player nextPlayer(){

        if (currentPlayer!=null){
          for(int i=0;i< Players.size();i++){
               if (Players.get(i) ==currentPlayer)
                    return Players.get((i+1)%Players.size());
        
          }
        }
    
    Random posAleatoria=new Random();
    int numeroJugadores=posAleatoria.nextInt(Players.size());
    
    return Players.get(numeroJugadores);         
    }
    
  
    private boolean nextTurnAllowed(){
     if (currentPlayer==null)
     return true;
     else{
        boolean stateOK;
            stateOK=currentPlayer.validState();
        return stateOK;
     }
    }
    
    public static Napakalaki getInstance (){
        return instance;
    }
    
    public CombatResult developCombat (){
        CombatResult combatResult=currentPlayer.combat(currentMonster);
        dealer.giveMonsterBack(currentMonster);
        return combatResult;
        
    }
    
    public void discardVisibleTreasures (ArrayList<Treasure> treasures){
        for (Treasure treasure: treasures){
            currentPlayer.discardVisibleTreasure(treasure);
            dealer.giveTreasureBack(treasure);
        }
        
    }

    public void discardHiddenTreasures (ArrayList<Treasure> treasures){
        for (Treasure treasure: treasures){
            currentPlayer.discardHiddenTreasure(treasure);
            dealer.giveTreasureBack(treasure);
        }
          
    }

    public void makeTreasuresVisible(ArrayList<Treasure> treasures){
        for (Treasure t:treasures){
            currentPlayer.makeTreasureVisible(t);        
        }
    }
    
    public boolean buyLevels(ArrayList<Treasure> visible, ArrayList<Treasure> hidden){
        boolean canI;
        canI=currentPlayer.buyLevels(visible, hidden);
        return canI;
    }
   

    public void initGame( ArrayList<String> players ){
      this.initPlayers(players);
      dealer.initCards();
      this.nextTurn();
        
    }

    public Player getCurrentPlayer(){
            return currentPlayer; 
    }
  
    public Monster getCurrentMonster(){
        return currentMonster; 
    }
    
    public boolean nextTurn(){
        boolean stateOK=this.nextTurnAllowed();
        if (stateOK){
        currentMonster= dealer.nextMonster();
        currentPlayer=this.nextPlayer();
        boolean dead=currentPlayer.isDead();
        
            if(dead){
              this.currentPlayer.initTreasures();
            }
        }    
 
     return stateOK;
    }
    
    public boolean endOfGame( CombatResult result ){
          return CombatResult.WinAndWinGame==result;
    }
    
}
