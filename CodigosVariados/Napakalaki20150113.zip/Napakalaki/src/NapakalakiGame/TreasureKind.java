 package NapakalakiGame;

public enum TreasureKind {
  armor,oneHand,bothHand,helmet,shoe,necklace;
}
