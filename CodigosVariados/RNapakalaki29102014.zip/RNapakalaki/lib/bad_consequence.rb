## To change this license header, choose License Headers in Project Properties.
# To change this template file, choose Tools | Templates
# and open the template in the editor.

class BadConsequence
  def initialize(aText=nil, someLevels=nil, someVisibleTreasures=0, 
    someHiddenTreasures=0, someSpecificVisibleTreasures=Array.new(), 
    someSpecificHiddenTreasures=Array.new(), death=false) 
  
    @aText=aText
    @levels=someLevels
    @someVisibleTreasures=someVisibleTreasures
    @someHiddenTreasures=someHiddenTreasures
    @someSpecificVisibleTreasures=someSpecificVisibleTreasures
    @someSpecificHiddenTreasures=someSpecificHiddenTreasures
    @death=death
    
  end
  
  def self.newLevelNumberOfTreasures (aText, someLevels, 
    someVisibleTreasures, someHiddenTreasures)
    new(aText,someLevels,someVisibleTreasures,someHiddenTreasures)
  end
  
  def self.newLevelSpecificTreasures (aText, someLevels,        
    someSpecificVisibleTreasures, someSpecificHiddenTreasures)
    new(aText,someLevels,0,0,someSpecificVisibleTreasures,someSpecificHiddenTreasures)
  end
  
  def self.newDeath (aText)
    new(aText,nil,0,0,Array.new(),Array.new(),true)
  end
  
private_class_method :new

attr_reader:levels
attr_reader:aText

  def to_s
  "Descripcion: #{@aText} \n Niveles perdidos: #{@someLevels} \n
  Tesoros visibles perdidos: #{@someVisibleTreasures} \n  
  Tesoros ocultos perdidos: #{@someHiddenTreasures}\n
  Muerte: #{@death}"
  end
  
end
