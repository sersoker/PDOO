package GUI;

import NapakalakiGame.Monster;

public class PrizeView extends javax.swing.JPanel {
Monster viewModel;
        
    public PrizeView() {
        initComponents();
    }
    
    public void setPrize (Monster m) {
        viewModel=m;
        Niveles.setText(Integer.toString(viewModel.getLevelsGained()));
        Tesoros.setText(Integer.toString(viewModel.getTreasuresGained()));
        
        repaint();
        revalidate();
      
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Tesoros = new javax.swing.JLabel();
        Niveles = new javax.swing.JLabel();

        Tesoros.setFont(new java.awt.Font("Tahoma", 0, 36)); // NOI18N
        Tesoros.setText("Tsr");

        Niveles.setFont(new java.awt.Font("Tahoma", 0, 36)); // NOI18N
        Niveles.setText("Lvl");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(Tesoros)
                .addContainerGap())
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(Niveles)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(Tesoros)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 11, Short.MAX_VALUE)
                .addComponent(Niveles))
        );
    }// </editor-fold>//GEN-END:initComponents


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Niveles;
    private javax.swing.JLabel Tesoros;
    // End of variables declaration//GEN-END:variables
}
