package GUI;

import NapakalakiGame.Monster;
import NapakalakiGame.Treasure;
import NapakalakiGame.TreasureKind;
import java.util.ArrayList;

public class BadConsequenceView extends javax.swing.JPanel {
    Monster monsterModel;
    
    public BadConsequenceView() {
        initComponents();
    }
    public void setBadConsequence (Monster m) {
        monsterModel = m;
        
        Niveles.setText(Integer.toString(monsterModel.getBadConsequence().getLevels()));
        Texto.setText(monsterModel.getBadConsequence().getText());
        Niveles.setText(Boolean.toString(monsterModel.getBadConsequence().myBadConsequenceIsDeath()));
        nOcultos.setText(Integer.toString(monsterModel.getBadConsequence().nHiddenTreasures()));
        nVisibles.setText(Integer.toString(monsterModel.getBadConsequence().nVisibleTreasures()));

        fillTreasurePanel (TOculEsp,monsterModel.getBadConsequence().getSpecificHiddenTreasures());
        fillTreasurePanel (TVisibleEsp, monsterModel.getBadConsequence().getSpecificVisibleTreasures());
       
        repaint();
        revalidate();
    }
    
    public void fillTreasurePanel (javax.swing.JPanel aPanel, ArrayList<TreasureKind> aList) {
        // Se elimina la información antigua
        aPanel.removeAll();
        // Se recorre la lista de tipos de tesoro construyendo y añadiendo sus vistas al panel
        for (TreasureKind t : aList) {
        TreasureKindView aTreasureKindView = new TreasureKindView();
        aTreasureKindView.setTreasureKind (t);
        aTreasureKindView.setVisible (true);
        aPanel.add (aTreasureKindView);
        }
        // Se fuerza la actualización visual del panel
        aPanel.repaint();
        aPanel.revalidate();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Texto = new javax.swing.JLabel();
        Niveles = new javax.swing.JLabel();
        nVisibles = new javax.swing.JLabel();
        nOcultos = new javax.swing.JLabel();
        death = new javax.swing.JLabel();
        TVisibleEsp = new javax.swing.JPanel();
        TOculEsp = new javax.swing.JPanel();

        Texto.setText("Texto");

        Niveles.setText("Niveles");

        nVisibles.setText("Nº Visibles");

        nOcultos.setText("Nº Ocultos");

        death.setText("Death");

        TVisibleEsp.setBorder(javax.swing.BorderFactory.createTitledBorder("TesorosVisiblesEspecificos"));

        javax.swing.GroupLayout TVisibleEspLayout = new javax.swing.GroupLayout(TVisibleEsp);
        TVisibleEsp.setLayout(TVisibleEspLayout);
        TVisibleEspLayout.setHorizontalGroup(
            TVisibleEspLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        TVisibleEspLayout.setVerticalGroup(
            TVisibleEspLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 34, Short.MAX_VALUE)
        );

        TOculEsp.setBorder(javax.swing.BorderFactory.createTitledBorder("TesorosOcultosEspecificos"));

        javax.swing.GroupLayout TOculEspLayout = new javax.swing.GroupLayout(TOculEsp);
        TOculEsp.setLayout(TOculEspLayout);
        TOculEspLayout.setHorizontalGroup(
            TOculEspLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        TOculEspLayout.setVerticalGroup(
            TOculEspLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 36, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(Texto, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(Niveles)
                                .addComponent(nVisibles)
                                .addComponent(death)))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(nOcultos)
                                .addGap(0, 90, Short.MAX_VALUE))
                            .addComponent(TVisibleEsp, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(TOculEsp, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addContainerGap())))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(Texto)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(Niveles)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(nVisibles)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(nOcultos)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(death)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(TVisibleEsp, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(TOculEsp, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Niveles;
    private javax.swing.JPanel TOculEsp;
    private javax.swing.JPanel TVisibleEsp;
    private javax.swing.JLabel Texto;
    private javax.swing.JLabel death;
    private javax.swing.JLabel nOcultos;
    private javax.swing.JLabel nVisibles;
    // End of variables declaration//GEN-END:variables
}
