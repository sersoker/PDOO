package GUI;
import NapakalakiGame.Napakalaki;

public class NapakalakiView extends javax.swing.JFrame {
    
    private Napakalaki napakalakiModel;
    
    public void setNapakalaki(Napakalaki nap){
       napakalakiModel=nap;
       VistaJugador.setPlayer(napakalakiModel.getCurrentPlayer());
       VistaJugador.setNapakalaki(napakalakiModel);
       repaint();
       revalidate();
    }
    

    /** Creates new form NapakalakiView */
    public NapakalakiView() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        VistaJugador = new GUI.PlayerView();
        VistaMonstruo = new GUI.MonsterView();
        resultado = new javax.swing.JLabel();
        Informacion = new javax.swing.JLabel();
        MeetMonster = new javax.swing.JButton();
        Combat = new javax.swing.JButton();
        NextTurn = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        VistaJugador.setBorder(javax.swing.BorderFactory.createTitledBorder("Jugador"));

        VistaMonstruo.setBorder(javax.swing.BorderFactory.createTitledBorder("Monstruo"));

        resultado.setText("ResultadoDeCombate");

        Informacion.setText("Otra Informacion");

        MeetMonster.setText("Meet The Monster");
        MeetMonster.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MeetMonsterActionPerformed(evt);
            }
        });

        Combat.setText("Combat");
        Combat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CombatActionPerformed(evt);
            }
        });

        NextTurn.setText("Next Turn");
        NextTurn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NextTurnActionPerformed(evt);
            }
        });

        org.jdesktop.layout.GroupLayout layout = new org.jdesktop.layout.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(layout.createSequentialGroup()
                .add(VistaJugador, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .add(18, 18, 18)
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(resultado, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 354, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(VistaMonstruo, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(Informacion, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 354, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(MeetMonster)
                    .add(Combat)
                    .add(NextTurn))
                .addContainerGap(org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(layout.createSequentialGroup()
                .add(6, 6, 6)
                .add(VistaMonstruo, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 338, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                .add(resultado, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 25, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(Informacion, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 25, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                .add(MeetMonster)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                .add(Combat)
                .add(18, 18, 18)
                .add(NextTurn)
                .addContainerGap(121, Short.MAX_VALUE))
            .add(VistaJugador, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void MeetMonsterActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MeetMonsterActionPerformed
       VistaMonstruo.setMonster(napakalakiModel.getCurrentMonster());
       repaint();
       revalidate();
    }//GEN-LAST:event_MeetMonsterActionPerformed

    private void CombatActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CombatActionPerformed
        resultado.setText(napakalakiModel.developCombat().toString());

    }//GEN-LAST:event_CombatActionPerformed

    private void NextTurnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NextTurnActionPerformed
     if(!napakalakiModel.nextTurn())
         Informacion.setText("No se puede pasar de turno");
    }//GEN-LAST:event_NextTurnActionPerformed

    public void showView(){
        this.setVisible(true);
    }
    
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Combat;
    private javax.swing.JLabel Informacion;
    private javax.swing.JButton MeetMonster;
    private javax.swing.JButton NextTurn;
    private GUI.PlayerView VistaJugador;
    private GUI.MonsterView VistaMonstruo;
    private javax.swing.JLabel resultado;
    // End of variables declaration//GEN-END:variables
}
