
package GUI;

import NapakalakiGame.Monster;

public class MonsterView extends javax.swing.JPanel {
Monster monsterModel;

    public MonsterView() {
        initComponents();
    }
    public void setMonster (Monster m) {
        monsterModel = m;
        if(m!=null){

        Titulo.setText(monsterModel.getName());
        Nivel.setText(Integer.toString(monsterModel.getCombatLevel()));
        badConsequenceView.setBadConsequence(monsterModel);
        VistaPrize.setPrize(monsterModel);
        }
        repaint();
        revalidate();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Titulo = new javax.swing.JLabel();
        badConsequenceView = new GUI.BadConsequenceView();
        VistaPrize = new GUI.PrizeView();
        Nivel = new javax.swing.JLabel();

        Titulo.setText("Titulo");

        badConsequenceView.setBorder(javax.swing.BorderFactory.createTitledBorder("BadConsequence"));

        javax.swing.GroupLayout badConsequenceViewLayout = new javax.swing.GroupLayout(badConsequenceView);
        badConsequenceView.setLayout(badConsequenceViewLayout);
        badConsequenceViewLayout.setHorizontalGroup(
            badConsequenceViewLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 192, Short.MAX_VALUE)
        );
        badConsequenceViewLayout.setVerticalGroup(
            badConsequenceViewLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        VistaPrize.setBorder(javax.swing.BorderFactory.createTitledBorder("Prize"));

        javax.swing.GroupLayout VistaPrizeLayout = new javax.swing.GroupLayout(VistaPrize);
        VistaPrize.setLayout(VistaPrizeLayout);
        VistaPrizeLayout.setHorizontalGroup(
            VistaPrizeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        VistaPrizeLayout.setVerticalGroup(
            VistaPrizeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        Nivel.setBackground(new java.awt.Color(0, 0, 0));
        Nivel.setFont(new java.awt.Font("Tahoma", 0, 35)); // NOI18N
        Nivel.setText("Lvl");
        Nivel.setToolTipText("");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(Titulo, javax.swing.GroupLayout.PREFERRED_SIZE, 281, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(Nivel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(badConsequenceView, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(VistaPrize, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Titulo, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Nivel))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(badConsequenceView, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(VistaPrize, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Nivel;
    private javax.swing.JLabel Titulo;
    private GUI.PrizeView VistaPrize;
    private GUI.BadConsequenceView badConsequenceView;
    // End of variables declaration//GEN-END:variables
}
