package NapakalakiGame;

public enum CombatResult {
    WinAndWinGame,
    Win,
    Lose,
    LoseAndEscape,
    LoseAndDie;
}
