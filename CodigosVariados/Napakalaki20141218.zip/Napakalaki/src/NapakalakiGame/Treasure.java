package NapakalakiGame;

public class Treasure {
    private String name; 
    private int goldCoins;
    private int minBonus;
    private int maxBonus;
    private TreasureKind type;

    public Treasure(String name, int goldCoins, int minBonus, int maxBonus, TreasureKind treasure) {
        this.name = name;
        this.goldCoins = goldCoins;
        this.minBonus = minBonus;
        this.maxBonus = maxBonus;
        this.type=treasure;
    }

    public int getGoldCoins() {
        return goldCoins;
    }

    public int getMaxBonus() {
        return maxBonus;
    }

    public int getMinBonus() {
        return minBonus;
    }   

    public String getName() {
        return name;
    }
    
    public TreasureKind getType(){
        return type;
    }
    
    public String toString(){
    return "Nombre = " + name + 
           " Tipo = "+ type+
            " Monedas = "+goldCoins+
            " Bonus minimo = " +minBonus+
            " Bonus maximo = "+maxBonus;
    }
}
