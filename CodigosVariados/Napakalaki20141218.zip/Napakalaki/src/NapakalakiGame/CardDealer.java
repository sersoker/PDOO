package NapakalakiGame;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;
import java.util.Collections;

public class CardDealer {
    private static final CardDealer instance = new CardDealer();
    private ArrayList <Treasure> unusedTreasures=new ArrayList();
    private ArrayList <Treasure> usedTreasures=new ArrayList();
    private ArrayList <Monster> unusedMonsters=new ArrayList();
    private ArrayList <Monster> usedMonsters=new ArrayList();
    
    private CardDealer() {
    }
    
    private static class CardDealerHolder {

        private static final CardDealer INSTANCE = new CardDealer();
    }
    
    private void initTreasureCardDeck(){
        usedTreasures.clear();
        unusedTreasures.clear();
        
        unusedTreasures.add(new Treasure("¡Si mi amo!",0,4,7,TreasureKind.helmet));
        unusedTreasures.add(new Treasure("Botas de investigacion",600,3,4,TreasureKind.shoe));
        unusedTreasures.add(new Treasure("Capucha de Cthulhu",500,3,5,TreasureKind.helmet));
        unusedTreasures.add(new Treasure("A prueba de babas",400,2,5,TreasureKind.armor));
        unusedTreasures.add(new Treasure("Botas de lluvia acida",800,1,1,TreasureKind.bothHand));
        unusedTreasures.add(new Treasure("Casco minero",400,2,4,TreasureKind.helmet));
        unusedTreasures.add(new Treasure("Ametralladora Thompson",600,4,8,TreasureKind.bothHand));
        unusedTreasures.add(new Treasure("Camiseta de la UGR",100,1,7,TreasureKind.armor));
        unusedTreasures.add(new Treasure("Clavo de rail ferroviario",400,3,6,TreasureKind.oneHand));
        unusedTreasures.add(new Treasure("Cuchillo de sushi arcano",300,2,3,TreasureKind.oneHand));
        unusedTreasures.add(new Treasure("Fez alopodo",700,3,5,TreasureKind.helmet));
        unusedTreasures.add(new Treasure("Hacha prehistorica",500,2,5,TreasureKind.oneHand));
        unusedTreasures.add(new Treasure("El aparato del Pr. Tesla",900,4,8,TreasureKind.armor));
        unusedTreasures.add(new Treasure("Gaita",500,4,5,TreasureKind.bothHand));
        unusedTreasures.add(new Treasure("Insecticida",300,2,3,TreasureKind.oneHand));
        unusedTreasures.add(new Treasure("Escopeta de 3 cañones",700,4,6,TreasureKind.bothHand));
        unusedTreasures.add(new Treasure("Garabato mistico",300,2,2,TreasureKind.oneHand));
        unusedTreasures.add(new Treasure("La fuerza de Mr. T",1000,10,10,TreasureKind.necklace));
        unusedTreasures.add(new Treasure("La rebeca metalica",400,2,3,TreasureKind.armor));
        unusedTreasures.add(new Treasure("Mazo de los antiguos",200,3,4,TreasureKind.oneHand));
        unusedTreasures.add(new Treasure("Necroplayboycon",300,3,5,TreasureKind.oneHand));
        unusedTreasures.add(new Treasure("Lanzallamas",800,4,8,TreasureKind.bothHand));
        unusedTreasures.add(new Treasure("Necrocomicon",100,1,1,TreasureKind.oneHand));
        unusedTreasures.add(new Treasure("Necronomicon",800,5,7,TreasureKind.bothHand));
        unusedTreasures.add(new Treasure("Linterna a 2 manos",400,3,6,TreasureKind.bothHand));
        unusedTreasures.add(new Treasure("Necrognomicon",200,2,4,TreasureKind.oneHand));
        unusedTreasures.add(new Treasure("Necrotelecom",300,2,3,TreasureKind.helmet));
        unusedTreasures.add(new Treasure("Porra preternatural",200,2,3,TreasureKind.oneHand));
        unusedTreasures.add(new Treasure("Tentaculo de pega",200,0,1,TreasureKind.helmet));
        unusedTreasures.add(new Treasure("Zapato deja-amigos",500,0,1,TreasureKind.shoe));
        unusedTreasures.add(new Treasure("Shogulador",600,1,1,TreasureKind.bothHand));
        unusedTreasures.add(new Treasure("Varita de atizamiento",400,3,4,TreasureKind.oneHand));
        

    }
    
    private void initMonsterCardDeck(){
        unusedMonsters.clear();
        usedMonsters.clear();
    
/*3 Byakhees de bonanza*/
   BadConsequence badConsequence = 
         new BadConsequence("Pierdes tu armadura visible y otra oculta",
         0,new ArrayList(Arrays.asList(TreasureKind.armor)),
         new ArrayList(Arrays.asList(TreasureKind.armor)));
         Prize pri = new Prize(2,1);
         unusedMonsters.add(new Monster("3 Byakhees de bonanza", 8, pri,badConsequence));   
    
/*Chibithulhu*/
         badConsequence = 
         new BadConsequence("Embobados con el lindo primigenio te descartas de tu casco visible",
         0,new ArrayList(Arrays.asList(TreasureKind.helmet)),new ArrayList());
         pri = new Prize(1,1);
         unusedMonsters.add(new Monster("Chibithulhu", 2, pri,badConsequence));

/*El sopor de Dunwich*/
         badConsequence = 
         new BadConsequence("El primordial bostezo contagioso, Pierdes el calzado visible.",
         0,new ArrayList(Arrays.asList(TreasureKind.shoe)),new ArrayList());
         pri = new Prize(1,1);
         unusedMonsters.add(new Monster("El sopor de Dunwich", 2,pri,badConsequence));
    
/*Angeles de la noche ibicenca*/    
        badConsequence = 
        new BadConsequence("Te atrapan para llevarte de fiesta y te dejan caer en mitad del vuelo. Descarta 1 mano visible y 1 mano oculta",
        0,new ArrayList(Arrays.asList(TreasureKind.oneHand))
        ,new ArrayList(Arrays.asList(TreasureKind.oneHand)));
        pri = new Prize(4,1);
        unusedMonsters.add(new Monster("Ángeles de la noche ibicenca", 14, pri,badConsequence));

/*El gorron en el umbral*/
        badConsequence = 
        new BadConsequence("Pierdes todos tus tesoros visibles",0,6,0);
        pri = new Prize(3,1);
        unusedMonsters.add(new Monster("El gorron en el umbral", 10, pri,badConsequence)); 

/*H.P. Munchcraft*/
        badConsequence =
        new BadConsequence("Pierdes la armadura visible",0,
        new ArrayList(Arrays.asList(TreasureKind.armor)),
        new ArrayList());
        pri = new Prize(2,1);
        unusedMonsters.add(new Monster("H.P. Munchcraft",6,pri,badConsequence));
    
/*Bichgooth*/
        badConsequence =
        new BadConsequence("Sientes bichos bajo la ropa. Pierdes la armadura visible",0,
        new ArrayList(Arrays.asList(TreasureKind.armor)),
        new ArrayList());
        pri = new Prize(1,1);
        unusedMonsters.add(new Monster("Bichgooth",2,pri,badConsequence));
 
/*El rey de rosa*/
        badConsequence = 
        new BadConsequence("Pierdes 5 niveles y 3 tesoros visibles",5,3,0);
        pri = new Prize(4,2);
        unusedMonsters.add(new Monster("El rey de rosa", 13, pri,badConsequence));     
    
 /*La que redacta en las tinieblas*/
        badConsequence = 
        new BadConsequence("Toses los pulmones y pierdes 2 niveles",2,0,0);
        pri = new Prize(1,1);
        unusedMonsters.add(new Monster("La que redacta en las tinieblas", 2, pri,badConsequence));     

/*Los hondos*/
        badConsequence = 
        new BadConsequence("Estos monstruos resultan bastante superficiales"
        + " y te aburren mortalmente. Estas muerto",true);
        pri = new Prize(2,1);
        unusedMonsters.add(new Monster("Los hondos", 8, pri,badConsequence));
   
/*Semillas Cthulhu*/
        badConsequence = 
        new BadConsequence("Pierdes 2 niveles y 2 tesoros oculto.",2,0,2);
        pri = new Prize(2,1);
        unusedMonsters.add(new Monster("Semillas Cthulhu", 4, pri,badConsequence));  

/*Dameargo*/
        badConsequence =
        new BadConsequence("Te intentas escaquear. Pierdes una mano visible",0,
        new ArrayList(Arrays.asList(TreasureKind.oneHand)),
        new ArrayList());
        pri = new Prize(2,1);
        unusedMonsters.add(new Monster("Dameargo",1,pri,badConsequence));

 /*Pollipolipo volante*/
        badConsequence = 
        new BadConsequence("Da mucho asquito.Pierdes 3 niveles.",3,0,0);
        pri = new Prize(1,1);
        unusedMonsters.add(new Monster("Pollipolipo volante", 3, pri,badConsequence)); 

/*Yskhtihyssg-Goth*/
        badConsequence = 
        new BadConsequence("No le hace gracia que pronuncien mal su nombre. Estas muerto",true);
        pri = new Prize(3,1);
        unusedMonsters.add(new Monster("Yskhtihyssg-Goth", 12, pri,badConsequence));

/*Familia feliz*/
        badConsequence = 
        new BadConsequence("La familia te atrapa. Estas muerto",true);
        pri = new Prize(4,1);
        unusedMonsters.add(new Monster("Familia feliz", 1, pri,badConsequence));

/*Roboggoth*/
        badConsequence =
        new BadConsequence("La quinta directiva primaria te obliga a perder 2 niveles y un tesoro 2 manos visible",2,
        new ArrayList(Arrays.asList(TreasureKind.bothHand)),new ArrayList());
        pri = new Prize(2,1);
        unusedMonsters.add(new Monster("Roboggoth",8,pri,badConsequence));
    
/*El espia*/
        badConsequence = 
        new BadConsequence("Te asustas en la noche. Pierdes un casco visible",
        0,new ArrayList(Arrays.asList(TreasureKind.helmet)),new ArrayList());
        pri = new Prize(1,1);
        unusedMonsters.add(new Monster("El espia", 5, pri,badConsequence));
   
/*El Lenguas*/
        badConsequence = 
        new BadConsequence("Menudo susto te llevas. Pierdes 2 niveles y 5 tesoros visibles",2,5,0);
        pri = new Prize(1,1);
        unusedMonsters.add(new Monster("El Lenguas", 20, pri,badConsequence));     

/*Bicefalo*/
        badConsequence = 
        new BadConsequence("Te faltan manos para tantas cabezas. Pierdes 3 niveles y tus tesoros visibles de las manos tesoros visibles",3,6,0);
        pri = new Prize(1,1);
        unusedMonsters.add(new Monster("Bicefalo", 20, pri,badConsequence));     
    
    }
    
    private void shuffleTreasures(){
        Collections.shuffle(unusedTreasures);
    }
    
    private void shuffleMonsters(){
        Collections.shuffle(unusedMonsters);
    
    }
    
    public static CardDealer getInstance() {
        return CardDealerHolder.INSTANCE;
    }
    
    public Treasure nextTreasure(){
            if ( unusedTreasures.isEmpty() ){
                unusedTreasures = usedTreasures;
                usedTreasures.clear();
                shuffleTreasures();
            }
                 //SHUFFLE TREASURES IMPLEMENTADO!!
            Treasure tesoro = unusedTreasures.get(0);
            unusedTreasures.remove(0);
            return tesoro;
    }
    
    public Monster nextMonster(){
            if ( unusedMonsters == new ArrayList<Monster>() ){
                unusedMonsters = usedMonsters;
                usedMonsters.clear();
            }
            shuffleMonsters(); 
            Monster monstruo = unusedMonsters.get(0);
            unusedMonsters.remove(0);
            return monstruo;
    }
    
    public void giveTreasureBack(Treasure t){
        usedTreasures.add(t);
    
    }
    
    public void giveMonsterBack(Monster m){
        usedMonsters.add(m);
    }
    
    public void initCards(){
        this.initTreasureCardDeck();
        this.initMonsterCardDeck();
        
        shuffleMonsters();
        shuffleTreasures();
    }
    
}