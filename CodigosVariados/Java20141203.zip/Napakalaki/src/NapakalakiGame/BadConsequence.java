package NapakalakiGame;
import java.util.ArrayList;

public class BadConsequence {
    private String text;
    private int levels;
    private int nVisibleTreasures ;
    private int nHiddenTreasures;
    private boolean death;
    private ArrayList <TreasureKind> specificHiddenTreasures = new ArrayList();
    private ArrayList <TreasureKind> specificVisibleTreasures = new ArrayList();
    

    public BadConsequence(String text, int levels, ArrayList<TreasureKind> tVisible, 
                        ArrayList<TreasureKind> tHidden){
        this.text = text;
        this.levels=levels;
        this.specificHiddenTreasures=tHidden;
        this.specificVisibleTreasures=tVisible;
        
    }
    
    public BadConsequence(String text, int levels ,int nvisibleTreasures, int nHiddenTreasures) {
        this.text = text;
        this.levels=levels;
        this.nVisibleTreasures = nvisibleTreasures;
        this.nHiddenTreasures = nHiddenTreasures;
    }

    public BadConsequence(String text, boolean death) {
        this.text = text;
        this.death = death;
    }

    public String getText() {
        return text;
    }
    
    public int getLevels(){
        return levels;
    }

    public int nHiddenTreasures(){
        return nHiddenTreasures;
    }

    public int nVisibleTreasures(){
        return nVisibleTreasures;
    }
    
    public ArrayList <TreasureKind> getSpecificHiddenTreasures(){
        return specificHiddenTreasures;
    }
    public ArrayList <TreasureKind> getSpecificVisibleTreasures(){
        return specificVisibleTreasures;
    }

    
    public String toString(){
    String cad = "Text = " + text + 
            "Level = "+ Integer.toString(levels)+
            "VisibleTreasures = "+ Integer.toString(nVisibleTreasures)+
            "HiddenTreasures = "+ Integer.toString(nHiddenTreasures)+
            "Death = "+ death;

    for(TreasureKind e:specificHiddenTreasures){
            cad = cad + e.toString();
        }
   
    for(TreasureKind e:specificVisibleTreasures){
            cad = cad + e.toString();
        }
        
    return cad;
    }
    
    boolean pierdeTipo (TreasureKind tipo){

        if (specificHiddenTreasures.contains(tipo)){
            return true;
        }
        if (specificVisibleTreasures.contains(tipo))
            return true;
        
     return false;
        
    }
    
    //PREGUNTAR
    public boolean isEmpty(){
       if (levels==0&&nVisibleTreasures==0&&nHiddenTreasures==0&&specificVisibleTreasures.isEmpty()&&specificHiddenTreasures.isEmpty()&&!death)
        return true;
       else
        return false;
    }
    
    public void substractVisibleTreasure(Treasure t){
        boolean encontrado = false;
        for ( int i = 0; i < specificVisibleTreasures.size() && !encontrado; i++ )
            if (t.getType()== specificVisibleTreasures.get(i)){
                encontrado = true;
                specificVisibleTreasures.remove(i);
            }
        if (!encontrado)
            nVisibleTreasures--;
    }
    
    public void substractHiddenTreasure(Treasure t){
        boolean encontrado = false;
        for ( int i = 0; i < specificHiddenTreasures.size() && !encontrado; i++ )
            if (t.getType()== specificHiddenTreasures.get(i)){
                encontrado = true;
                specificHiddenTreasures.remove(i);
            }
        if (!encontrado)
            nHiddenTreasures--;    
    }
    
    public BadConsequence adjustToFitTreasureLists(ArrayList <Treasure> v, ArrayList <Treasure>h){
        this.levels=0;
        boolean encontrado;
        for (int i = 0; i < specificVisibleTreasures.size(); i++){
            encontrado = false;
            for (int j = 0; j < v.size() && !encontrado; j++){
                if ( specificVisibleTreasures.get(i) == v.get(j).getType() )
                    encontrado = true;
            }
            
            if (!encontrado){
                specificVisibleTreasures.remove(specificVisibleTreasures.get(i));
                i--;
            }
        }

        for (int i = 0; i < specificHiddenTreasures.size(); i++){
            encontrado = false;
            for (int j = 0; j < h.size() && !encontrado; j++){
                if ( specificHiddenTreasures.get(i) == h.get(j).getType() )
                    encontrado = true;
            }
            
            if (!encontrado){
                specificHiddenTreasures.remove(specificHiddenTreasures.get(i));
                i--;
            }
        }
        
        if (nVisibleTreasures > v.size())
            nVisibleTreasures = v.size();
        
        if (nHiddenTreasures > v.size())
            nHiddenTreasures = v.size();

    return this;
    }
    
    public boolean myBadConsequenceIsDeath(){
        return death;
    }
}
