package NapakalakiGame;

import java.util.Random;
public class Dice {
    
    private static final Dice instance = new Dice();
    
    private Dice() {
    }
    
    public static Dice getInstance() {
        return instance;
    }
    
    public int nextNumber(){
        Random diceRoller = new Random();
        int roll = diceRoller.nextInt(6) + 1;
        return roll;
    }
    
}
