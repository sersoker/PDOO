package NapakalakiGame;

public class Monster {
    private String name;
    private int combatLevel;
    private Prize price;
    private BadConsequence badConsequence;

    public Monster(String name, int combatLevel, Prize price, BadConsequence bc) {
        this.name = name;
        this.combatLevel = combatLevel;
        this.price = price;
        this.badConsequence = bc;
    }
    
    public String getName(){
        return name;
    }
    
    public int getCombatLevel(){
        return combatLevel;
    }
    
    public String toString(){
    return "Name = " + name + 
            " Combat level = "+ Integer.toString(combatLevel);
    }
        
    public boolean soloNivel(){
       if (badConsequence.getLevels()>0&&badConsequence.nHiddenTreasures()==0&&badConsequence.nVisibleTreasures()==0)
        return true;
       else
        return false;
    }
//   
//    public int buenRolloNivel(){
//        return price.getLevels();
//    }
    
    public boolean perdida(TreasureKind tipo){
     //   System.out.println(bc.pierdeTipo(tipo));
        return badConsequence.pierdeTipo(tipo);
    }
    
    public BadConsequence getBadConsequence(){
        return badConsequence;        
    }
    
    public int getLevelsGained(){
        return this.price.getLevels();
    }        
    
    public int getTreasuresGained(){
        return this.price.getTreasures();
    }
    
    public boolean kills(){
        return this.badConsequence.myBadConsequenceIsDeath();
    }
}
