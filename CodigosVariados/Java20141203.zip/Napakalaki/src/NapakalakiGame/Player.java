package NapakalakiGame;

import java.util.ArrayList;

public class Player {
    private boolean dead;
    private String name;
    private int level;
    private BadConsequence pendingBadConsequence=null;
    private ArrayList <Treasure> hiddenTreasures=new ArrayList();
    private ArrayList <Treasure> visibleTreasures=new ArrayList();
    

    public Player(String name) {
        this.name = name;
        this.level= 1;
        this.dead = true;
    }
    
    private void bringToLife(){

        this.dead=false;
        this.level=1;

    }
    
    public String toString(){
    String salida = "Nombre Jugador = "+ name+
                        " Nivel de jugador = "+ level + "\n";
    
    if (pendingBadConsequence!=null)
        salida = salida + this.pendingBadConsequence.toString();
    
    return salida;
    }
    
    public String getName(){
        return name;
    }
    
    private int cuentaNV(){
      int nivel=0;
      boolean contenido=visibleTreasures.contains(TreasureKind.necklace);
      //boolean contenido=false;
      if (!contenido){
        for(Treasure t: visibleTreasures){
        nivel= nivel+ t.getMinBonus();
        }
      }
      else{
        for(Treasure t: visibleTreasures){
        nivel= nivel+ t.getMaxBonus();
        }
      }
    
      return nivel;
    }
  
    
    private int getCombatLevel(){
        return level+this.cuentaNV();
    }
    
    private void incrementLevels(int i){
            this.level=level+i;
    
    }
   
    private void decrementLevels(int i){
        if ((level-i)<=0){
            this.die();
        }            
        else{
            level=level-i;
        }
    
    }
    
    private void setPendingBadConsequence(BadConsequence b){
        this.pendingBadConsequence=b;
    
    }
    
    private void dieIfNoTreasures(){
        if (visibleTreasures.isEmpty()&&hiddenTreasures.isEmpty())
            this.dead=true;    
    }
    
    
    private void discardNecklacelfVisible(){
        CardDealer cd=CardDealer.getInstance();
            for(Treasure t: visibleTreasures){
                if(t.getType()==TreasureKind.necklace){
                    this.visibleTreasures.remove(t);
                    cd.giveTreasureBack(t);
                }
                    
            }
      
    }
    
    private void die (){
        level=1;
        CardDealer dealer= CardDealer.getInstance();
        
        for (Treasure treasure: visibleTreasures){
            dealer.giveTreasureBack(treasure);
        }
        visibleTreasures.clear();
        
        for (Treasure treasure: hiddenTreasures){
            dealer.giveTreasureBack(treasure);
        }
        hiddenTreasures.clear();
        
        this.dieIfNoTreasures();
    }

    private float computeGoldCoinsValue(ArrayList <Treasure> t){
        float monedas=0;    
        for(Treasure moneda: t){
                monedas=monedas+moneda.getGoldCoins();
         }
     System.out.println("Cuenta de monedas"+monedas);
     return monedas;
    }

    private boolean canIBuyLevels(int i){
        if ((level+i)>=10)
        return false;
        else
        return true;
    
    }

    private void applyPrize(Monster currentMonster){
        int nLevels=currentMonster.getLevelsGained();
        this.incrementLevels(nLevels);
        int nTreasures=currentMonster.getTreasuresGained();
        if(nTreasures>0){
            CardDealer dealer= CardDealer.getInstance();
            for (int i=1;i<=nTreasures;i++){
                Treasure treasure=dealer.nextTreasure();
                hiddenTreasures.add(treasure);
            }
        }
    
    }
    
    private void applyBadConsequence(BadConsequence bad){
        int nLevels=bad.getLevels();
        this.decrementLevels(nLevels);
        BadConsequence pendingBad=bad.adjustToFitTreasureLists(visibleTreasures, hiddenTreasures);
        this.setPendingBadConsequence(pendingBad);
    }

    private boolean canMakeTreasureVisible(Treasure t){
        
        if (t.getType()==TreasureKind.oneHand||t.getType()==TreasureKind.bothHand){
           for(Treasure te: visibleTreasures){
               if(te.getType()==TreasureKind.bothHand)
                   return false;
           }
        }
        if(t.getType()==TreasureKind.bothHand){
         for(Treasure te: visibleTreasures){
             if (te.getType()==TreasureKind.oneHand)
                 return false;
             }        
        }      
        
        if(t.getType()==TreasureKind.oneHand){
        int tengo=0;
         for(Treasure te: visibleTreasures){
             if (te.getType()==TreasureKind.oneHand)
                 tengo++;
             }
        if (tengo<=1)
            return true;
        else
            return false;
                    
        }

        for(Treasure te: visibleTreasures){
            if (t.getType()==te.getType())
                   return false;
        }
        
        return true;
    }
    
    private int howManyVisibleTreasures(TreasureKind tKind){
        int cuantos=0;
           for(Treasure t: visibleTreasures){
               if (t.getType()==tKind)
                   cuantos++;
           }
        
        return cuantos;
    }
    
    public boolean isDead(){
        return dead;
    }
    
    public ArrayList<Treasure> getHiddenTreasures(){
        return this.hiddenTreasures;
    
    }
    
    public ArrayList<Treasure> getVisibleTreasures(){
        return this.visibleTreasures;
    
    }
    
   public CombatResult combat (Monster m){
    CombatResult combatResult;
    int myLevel=this.getCombatLevel();
    int monsterLevel=m.getCombatLevel();
       if (myLevel>monsterLevel){
           this.applyPrize(m);   
           if(this.level>=10)
           combatResult=CombatResult.WinAndWinGame;
           else
           combatResult=CombatResult.Win;
       }
       else{
        Dice dice= Dice.getInstance();
        int escape= dice.nextNumber(); 
        if(escape<5){
            boolean amIDead=m.kills();
            if(amIDead){
                this.die();
                combatResult=CombatResult.LoseAndDie;
            }
            else{
                BadConsequence bad=m.getBadConsequence();
                combatResult=CombatResult.Lose;
                this.applyBadConsequence(bad);    
            }
        }
          else
              combatResult=CombatResult.LoseAndEscape;
       }
    this.discardNecklacelfVisible();
    return combatResult; 
    }    

    public void makeTreasureVisible(Treasure t){
        boolean canI=this.canMakeTreasureVisible(t);
        if (canI){
            visibleTreasures.add(t);
            hiddenTreasures.remove(t);
        }
    
    }
    
    public void discardVisibleTreasure(Treasure t){
        visibleTreasures.remove(t);
        if (pendingBadConsequence!=null && !pendingBadConsequence.isEmpty())
           pendingBadConsequence.substractVisibleTreasure(t);
        this.dieIfNoTreasures();
    
    }
    
    public void discardHiddenTreasure(Treasure t){
        hiddenTreasures.remove(t);
        if (pendingBadConsequence!=null && !pendingBadConsequence.isEmpty())
           pendingBadConsequence.substractHiddenTreasure(t);
        this.dieIfNoTreasures();
    
    }
    
    public boolean buyLevels(ArrayList<Treasure> visible, ArrayList<Treasure> hidden ){
        float levelsMayBought=this.computeGoldCoinsValue(visible);
        levelsMayBought+=this.computeGoldCoinsValue(hidden);

        float aux=(levelsMayBought-(levelsMayBought%1000))/1000;
        System.out.println("Valor aux:"+aux);
        int levels=(int)(aux);
        
        boolean canI=this.canIBuyLevels(levels);
        System.out.println("Entra en buy y saca niveles:"+levels);
        if (canI)
            this.incrementLevels(levels);
        visibleTreasures.removeAll(visible);
        hiddenTreasures.removeAll(hidden);
        CardDealer dealer=CardDealer.getInstance();
        for(Treasure treasure: visible){
            dealer.giveTreasureBack(treasure);
        }
        for(Treasure treasure: hidden){
            dealer.giveTreasureBack(treasure);
        }
    return canI;
    }
    
   
    public boolean validState(){
    boolean salida=false;
    if(pendingBadConsequence==null)
        return true;
    else {
      if (pendingBadConsequence.isEmpty()){
      int num_tesoros=0;
          for(Treasure t: hiddenTreasures){
              num_tesoros++;
          }
      if(num_tesoros<=4)
          salida=true;
      if(num_tesoros>4)
          salida=false;
    }
    }
    return salida;
    }
    
    public void initTreasures(){
        CardDealer dealer = CardDealer.getInstance();
        Dice dice = Dice.getInstance();
        this.bringToLife();
        Treasure treasure = dealer.nextTreasure();
        this.hiddenTreasures.add(treasure);
        int number=dice.nextNumber();   
        if (number>1){
            treasure=dealer.nextTreasure();
           this.hiddenTreasures.add(treasure);
        
        }
        if(number==6){
            treasure=dealer.nextTreasure();
            this.hiddenTreasures.add(treasure);
        }
     
    }
    
    public boolean hasVisibleTreasures(){
        int nivel=0;
        for(Treasure t: visibleTreasures){
            nivel++;
        }
        if (nivel>0)
            return true;
        else
            return false;
    }
    
    public int getlevels(){
        return level;
    }
    
    
}













